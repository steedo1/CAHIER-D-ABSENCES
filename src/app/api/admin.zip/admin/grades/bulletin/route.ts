// src/app/api/admin/grades/bulletin/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getSupabaseServerClient } from "@/lib/supabase-server";
import { getSupabaseServiceClient } from "@/lib/supabaseAdmin";
import type { SupabaseClient } from "@supabase/supabase-js";
import crypto from "crypto";
import QRCode from "qrcode";

// ✅ QR court stocké en DB (table bulletin_qr_codes)
import { getOrCreateBulletinShortCode } from "@/lib/bulletin-qr-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Role =
  | "super_admin"
  | "admin"
  | "educator"
  | "teacher"
  | "parent"
  | string;

type ClassRow = {
  id: string;
  label?: string | null;
  code?: string | null;
  institution_id?: string | null;
  academic_year?: string | null;
  head_teacher_id?: string | null;
  level?: string | null;
  official_track_code?: string | null;
};

type HeadTeacherRow = {
  id: string;
  display_name?: string | null;
  phone?: string | null;
  email?: string | null;
};

type EvalRow = {
  id: string;
  class_id: string;
  subject_id: string | null;
  teacher_id: string | null; // ✅ prof qui a créé l'évaluation
  eval_date: string;
  scale: number;
  coeff: number;
  is_published: boolean;
  subject_component_id?: string | null; // ✅ sous-matière éventuelle
};

type ScoreRow = {
  evaluation_id: string;
  student_id: string;
  score: number | null;
};

type GradeAdjustmentBonusRow = {
  student_id: string;
  subject_id: string | null;
  grading_period_id?: string | null;
  bonus: number | string | null;
};

type AdjustmentBonusMaps = {
  subjectBonusByStudent: Map<string, Map<string, number>>;
  generalBonusByStudent: Map<string, number>;
};

type ClassStudentRow = {
  student_id: string;
  students?:
    | {
        full_name?: string | null;
        last_name?: string | null;
        first_name?: string | null;
        matricule?: string | null;

        // ✅ photo (ajouté sans retirer quoi que ce soit)
        photo_url?: string | null;

        gender?: string | null;
        birthdate?: string | null;
        birth_place?: string | null;
        nationality?: string | null;
        regime?: string | null;
        is_repeater?: boolean | null;
        is_boarder?: boolean | null;
        is_affecte?: boolean | null;
      }
    | null;
};

type SubjectRow = {
  id: string;
  name?: string | null;
  code?: string | null;
};

type SubjectCoeffRow = {
  subject_id: string;
  coeff: number;
  include_in_average?: boolean | null;
  level?: string | null;
};

type SubjectGradePolicyRow = {
  subject_id: string;
  include_in_general_average?: boolean | null;
  include_in_conduct_average?: boolean | null;
  conduct_weight?: number | null;
  is_active?: boolean | null;
};

type BulletinSubjectGroupItem = {
  id: string;
  group_id: string;
  subject_id: string;
  subject_name: string;
  order_index: number;
  subject_coeff_override: number | null;
  is_optional: boolean;
};

type BulletinSubjectGroup = {
  id: string;
  code: string;
  label: string;
  short_label: string | null;
  order_index: number;
  is_active: boolean;
  annual_coeff: number;
  items: BulletinSubjectGroupItem[];
};

// ✅ Sous-matières renvoyées au front
type BulletinSubjectComponent = {
  id: string;
  subject_id: string; // subjects.id parent
  label: string;
  short_label: string | null;
  coeff_in_subject: number;
  order_index: number;
};

type GradePeriodRow = {
  id: string;
  academic_year: string | null;
  code: string | null;
  label: string | null;
  short_label: string | null;
  start_date: string;
  end_date: string;
  coeff: number | null;
};

type BulletinNcOverrideRow = {
  id: string;
  student_id: string;
  scope: "period" | "annual" | string;
  is_nc: boolean;
  reason: string | null;
  missing_subjects_snapshot: any;
  period_from?: string | null;
  period_to?: string | null;
  academic_year?: string | null;
};

/* ───────── helpers nombres ───────── */

// ✅ IMPORTANT: on garde plus de précision (4 décimales) pour éviter
// les écarts Total vs somme/pondération (ex: Français = sous-matières).
function cleanNumber(x: any, precision: number = 2): number | null {
  const n = Number(x);
  if (!Number.isFinite(n)) return null;
  return Number(n.toFixed(precision));
}

function cleanCoeff(c: any): number {
  const n = Number(c);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Number(n.toFixed(2));
}

function clampAverage20(value: any): number | null {
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return Math.max(0, Math.min(20, n));
}

function isUuid(v: string): boolean {
  return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(
    v
  );
}

// ✅ Normalisation du niveau "bulletin"
function normalizeBulletinLevel(level?: string | null): string | null {
  if (!level) return null;
  const x = String(level).trim().toLowerCase();

  if (["6e", "5e", "4e", "3e", "seconde", "première", "terminale"].includes(x)) {
    return x;
  }
  if (x === "premiere") return "première";

  if (x.startsWith("2de") || x.startsWith("2nde") || x.startsWith("2")) return "seconde";
  if (x.startsWith("1re") || x.startsWith("1ere") || x.startsWith("1")) return "première";
  if (x.startsWith("t")) return "terminale";

  return null;
}

function normalizeAsciiToken(value?: string | null): string {
  return String(value ?? "")
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

type InstitutionMeta = {
  id: string;
  name?: string | null;
  code_unique?: string | null;
  acronym?: string | null;
};

const CSCA_INSTITUTION_IDS = new Set([
  // Sécurité : garde-fou pour la base actuelle du Cours Secondaire Catholique d'Aboisso.
  "ee34ab2a-8033-4e0b-acf0-05979cce1697",
]);

function isCSCAInstitution(meta: InstitutionMeta | null | undefined): boolean {
  if (!meta) return false;
  const id = String(meta.id || "").trim();
  if (CSCA_INSTITUTION_IDS.has(id)) return true;

  const name = normalizeAsciiToken(meta.name);
  const code = normalizeAsciiToken(meta.code_unique);
  const acronym = normalizeAsciiToken(meta.acronym);
  const all = `${name} ${code} ${acronym}`;

  return (
    acronym === "csca" ||
    code === "csca" ||
    all.includes("csca") ||
    (name.includes("courssecondairecatholique") && name.includes("aboisso"))
  );
}

function isCSCALatinOrReligionSubjectMeta(subject: SubjectRow | null | undefined): boolean {
  const key = normalizeAsciiToken(`${subject?.code ?? ""} ${subject?.name ?? ""}`);
  if (!key) return false;

  return (
    key.includes("latin") ||
    key.includes("religion") ||
    key.includes("religieux") ||
    key === "reg" ||
    key === "rel"
  );
}

/**
 * ✅ Clé officielle utilisée pour les coefficients et sous-matières.
 *
 * IMPORTANT : on ne doit plus écraser 1èreA1 / 1èreA2 en simple "première".
 * official_track_code devient prioritaire pour éviter la confusion entre :
 * - 1A1 comme nom de division ;
 * - 1ère A1 comme série officielle DESPS/coefficients.
 */
function normalizeCoeffLevelKey(level?: string | null): string | null {
  const x = normalizeAsciiToken(level);
  if (!x) return null;

  if (/^(6|6e|6eme|sixieme)$/.test(x)) return "6eme";
  if (/^(5|5e|5eme|cinquieme)$/.test(x)) return "5eme";
  if (/^(4|4e|4eme|quatrieme)$/.test(x)) return "4eme";
  if (/^(3|3e|3eme|troisieme)$/.test(x)) return "3eme";

  if (/^(2ndea|2dea|secondea|2a|2a[0-9]+)$/.test(x)) return "2ndeA";
  if (/^(2ndec|2dec|secondec|2c|2c[0-9]+)$/.test(x)) return "2ndeC";
  if (/^(2nde|2de|seconde)$/.test(x)) return "seconde";

  if (/^(1erea1|premierea1|1rea1|1a1)$/.test(x)) return "1ereA1";
  if (/^(1erea2|premierea2|1rea2|1a2|1a|1a[0-9]+)$/.test(x)) return "1ereA2";
  if (/^(1erec|premierec|1rec|1c|1c[0-9]+)$/.test(x)) return "1ereC";
  if (/^(1ered|premiered|1red|1d|1d[0-9]+)$/.test(x)) return "1ereD";
  if (/^(1ere|1re|premiere)$/.test(x)) return "première";

  if (/^(tlea1|terminalea1|ta1)$/.test(x)) return "tleA1";
  if (/^(tlea2|terminalea2|ta2|tlea|terminalea|ta|ta[0-9]+)$/.test(x)) return "tleA2";
  if (/^(tlec|terminalec|tc|tc[0-9]+)$/.test(x)) return "tleC";
  if (/^(tled|terminaled|td|td[0-9]+)$/.test(x)) return "tleD";
  if (/^(tle|terminal|terminale)$/.test(x)) return "terminale";

  return x;
}

function normalizeStoredLevel(level?: string | null): string | null {
  const specific = normalizeCoeffLevelKey(level);
  if (specific) return specific;

  const n = normalizeBulletinLevel(level);
  if (n) return n;

  const raw = String(level ?? "").trim().toLowerCase();
  return raw || null;
}

function pushUniqueLevelCandidate(list: string[], value?: string | null) {
  const key = normalizeCoeffLevelKey(value);
  if (key && !list.includes(key)) list.push(key);
}

const STRICT_OFFICIAL_COEFF_LEVELS = new Set([
  /**
   * On reste strict uniquement sur les séries A, car A1 et A2 ont
   * des coefficients différents et ne doivent jamais se remplacer.
   *
   * Pour les séries non ambiguës (D, C, 2nde, collège), on garde la
   * compatibilité avec les anciens libellés déjà présents en base
   * grâce à normalizeStoredLevel() : 1reD -> 1ereD, TD -> tleD, etc.
   */
  "1ereA1",
  "1ereA2",
  "tleA1",
  "tleA2",
]);

function buildCoeffLevelCandidates(classRow: ClassRow, bulletinLevel: string | null): string[] {
  const out: string[] = [];

  /**
   * Si la classe porte une série officielle, elle devient la vérité métier.
   * On ne retombe surtout pas sur le label de classe :
   * - 1A1 peut être une division de A2 ;
   * - TA1 peut être une division de A2 ;
   * - A1 et A2 n'ont pas les mêmes coefficients.
   */
  const official = normalizeCoeffLevelKey(classRow.official_track_code);
  if (official) {
    out.push(official);

    // Les séries A restent strictes : A1 et A2 n'ont pas les mêmes coefficients.
    if (STRICT_OFFICIAL_COEFF_LEVELS.has(official)) return out;

    // Pour les autres séries/niveaux, on ajoute les anciens libellés en secours.
    // Exemple : official 1ereD peut retrouver des lignes historiques 1reD.
    pushUniqueLevelCandidate(out, classRow.level);
    pushUniqueLevelCandidate(out, classRow.code);
    pushUniqueLevelCandidate(out, classRow.label);
    pushUniqueLevelCandidate(out, bulletinLevel);
    if (bulletinLevel && !out.includes(bulletinLevel)) out.push(bulletinLevel);
    return out;
  }

  pushUniqueLevelCandidate(out, classRow.level);
  pushUniqueLevelCandidate(out, classRow.code);
  pushUniqueLevelCandidate(out, classRow.label);
  pushUniqueLevelCandidate(out, bulletinLevel);

  if (bulletinLevel && !out.includes(bulletinLevel)) out.push(bulletinLevel);

  return out;
}

/**
 * ✅ Les sous-matières du bulletin ne sont autorisées que pour le collège.
 *
 * Exemple métier :
 * - 6e/5e/4e/3e : Français peut avoir Composition, Expression, Orthographe…
 * - Seconde/Première/Terminale : Français reste une matière unique.
 *
 * Les notes avec subject_component_id ne sont pas supprimées : elles contribuent
 * simplement à la moyenne de la matière principale via le calcul direct.
 */
function allowSubjectComponentsForBulletinLevel(level?: string | null): boolean {
  const n = normalizeBulletinLevel(level);
  return n === "6e" || n === "5e" || n === "4e" || n === "3e";
}

function pickBestCoeffRow(
  rows: SubjectCoeffRow[],
  wantedLevels: Array<string | null | undefined>
): SubjectCoeffRow | null {
  if (!rows.length) return null;

  const wanted = wantedLevels
    .map((level) => normalizeStoredLevel(level))
    .filter((level): level is string => Boolean(level));

  for (const key of wanted) {
    const exact = rows.find((r) => normalizeStoredLevel(r.level) === key);
    if (exact) return exact;
  }

  const globalRow = rows.find((r) => !normalizeStoredLevel(r.level));
  if (globalRow) return globalRow;

  // Pas de fallback arbitraire : il vaut mieux signaler un coefficient manquant
  // que prendre par erreur les coefficients d'une autre série (A1/A2 notamment).
  if (wanted.length) return null;

  return rows[0] ?? null;
}

function pickBestComponentRows<T extends { level?: string | null }>(
  rows: T[],
  wantedLevels: Array<string | null | undefined>
): T[] {
  if (!rows.length) return [];

  const wanted = wantedLevels
    .map((level) => normalizeStoredLevel(level))
    .filter((level): level is string => Boolean(level));

  for (const key of wanted) {
    const exact = rows.filter((r) => normalizeStoredLevel(r.level) === key);
    if (exact.length) return exact;
  }

  const globalRows = rows.filter((r) => !normalizeStoredLevel(r.level));
  if (globalRows.length) return globalRows;

  // Même règle que pour les coefficients : ne pas utiliser les sous-matières
  // d'une autre série/niveau quand une série officielle est attendue.
  if (wanted.length) return [];

  return rows;
}

function computeGroupAnnualCoeff(
  group: BulletinSubjectGroup,
  coeffBySubject: Map<string, { coeff: number; include: boolean }>
): number {
  let sumCoeff = 0;

  for (const item of group.items ?? []) {
    const base = coeffBySubject.get(String(item.subject_id));
    if (base?.include === false) continue;

    // Le coefficient officiel de la matière est prioritaire.
    // subject_coeff_override ne doit être utilisé qu'en secours si le coefficient officiel manque.
    const officialCoeff = Number(base?.coeff ?? 0);
    if (Number.isFinite(officialCoeff) && officialCoeff > 0) {
      sumCoeff += officialCoeff;
      continue;
    }

    const override = Number(item.subject_coeff_override ?? NaN);
    if (Number.isFinite(override) && override > 0) sumCoeff += override;
  }

  return cleanCoeff(sumCoeff);
}

/* ───────── classification bilans (API) ───────── */

function normText(s?: string | null) {
  return (s ?? "").toString().trim().toLowerCase();
}

// ⚠️ EPS / EDHC / Musique / Arts / Conduite / Vie scolaire => AUTRES
function isOtherSubject(name?: string | null, code?: string | null): boolean {
  const n = normText(name);
  const c = normText(code);

  return (
    /(^|\b)(eps|e\.p\.s|sport)(\b|$)/.test(c) ||
    /(^|\b)(eps|e\.p\.s|sport)(\b|$)/.test(n) ||
    /(education\s*physique|éducation\s*physique|sportive|eps)/.test(n) ||
    /(edhc|civique|citoyenn|vie\s*scolaire|conduite|discipline)/.test(n) ||
    /(musique|chant|arts?\s*plastiques|dessin|th[eé]atre)/.test(n) ||
    /(tic|tice|informatique\s*(de\s*base)?)/.test(n) ||
    /(entrepreneuriat|travail\s*manuel|tm|bonus)/.test(n)
  );
}

// ✅ PHILO => LETTRES
function isPhiloSubject(name?: string | null, code?: string | null): boolean {
  const n = normText(name);
  const c = normText(code);
  return /(philo|philosoph)/.test(n) || /(philo|philosoph)/.test(c);
}

// ✅ LETTRES / langues / Histoire-Géo
function isLettersSubject(name?: string | null, code?: string | null): boolean {
  // ⚠️ si c'est déjà "AUTRES", on ne le classe pas en lettres
  if (isOtherSubject(name, code)) return false;

  const n = normText(name);
  const c = normText(code);

  // PHILO est toujours dans LETTRES
  if (isPhiloSubject(name, code)) return true;

  // codes courts fréquents
  if (
    /(^|\b)(fr|francais|français|ang|anglais|esp|espagnol|all|allemand|ar|arabe|hg|hist|histoire|geo|geographie|géographie|lit|litt|eco|economie|économie)(\b|$)/.test(
      c
    )
  ) {
    return true;
  }

  // noms
  return (
    /(fran[cç]ais|french|anglais|english|espagnol|spanish|allemand|german|arabe|arabic)/.test(n) ||
    /(histoire|hist\.|g[eé]ographie|histoire\s*-?\s*g[eé]o|hg)/.test(n) ||
    /(litt[eé]r|lettres|grammaire|orthograph|conjug|lecture|r[eé]daction|expression|compr[eé]hension)/.test(
      n
    ) ||
    /(economie|gestion|comptabilit|droit)/.test(n)
  );
}


// ✅ Sciences
function isScienceSubject(name?: string | null, code?: string | null): boolean {
  const n = normText(name);
  const c = normText(code);

  // ⚠️ ne PAS classer EPS/EDHC/Musique en sciences
  if (isOtherSubject(name, code)) return false;

  return (
    /(math|math[ée]m|pc|phys|chim|svt|bio|science|info|algo|stat|techno|thermo|mec|m[ée]can|electr|[ée]lectr|opt|astron|geol|g[eé]ol)/.test(c) ||
    /(math|math[ée]m|physique|chimie|svt|biolog|scienc|informat|algo|statist|technolog|thermo|m[ée]can|mecaniq|[ée]lectr|optique|astronom|g[eé]olog|g[eé]ophys)/.test(n)
  );
}

function groupKey(s?: string | null) {
  return (s ?? "")
    .toString()
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "");
}

function findGroupByMeaning(
  groups: BulletinSubjectGroup[],
  meaning: "LETTRES" | "SCIENCES" | "AUTRES"
): BulletinSubjectGroup | null {
  const keys =
    meaning === "LETTRES"
      ? ["BILANLETTRES", "LETTRES", "LITTERAIRE", "LITTERATURE", "LANGUES"]
      : meaning === "SCIENCES"
      ? ["BILANSCIENCES", "SCIENCES", "SCIENTIFIQUE"]
      : ["BILANAUTRES", "AUTRES", "DIVERS", "VIESCOLAIRE", "CONDUITE"];

  for (const g of groups) {
    const k1 = groupKey(g.code);
    const k2 = groupKey(g.label);
    if (keys.includes(k1) || keys.includes(k2)) return g;
  }
  return null;
}

/* ───────── QR code (court /v/[code]) + fallback token ───────── */

const BULLETIN_VERIFY_SHORT_PREFIX = "/v"; // ✅ nouvelle page publique: /v/[code]
const BULLETIN_VERIFY_LEGACY_PATH = "/verify/bulletin"; // fallback historique

type BulletinQRPayload = {
  v: 1;
  instId: string;
  classId: string;
  studentId: string;
  academicYear: string | null;
  periodFrom: string | null;
  periodTo: string | null;
  periodLabel: string | null;
  periodShortLabel?: string | null;

  // ✅ Snapshot (moyennes déjà calculées côté bulletin, utile pour la vérification publique sans cookie)
  s?:
    | {
        g?: number | null; // general_avg
        a?: number | null; // annual_avg
      }
    | null;

  iat: number; // ms
};

function b64urlEncode(buf: Buffer) {
  return buf
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function signBulletinQRToken(payload: Omit<BulletinQRPayload, "v" | "iat">): string | null {
  const secret = process.env.BULLETIN_QR_SECRET;
  if (!secret) return null;

  const full: BulletinQRPayload = { v: 1, iat: Date.now(), ...payload };
  const payloadB64 = b64urlEncode(Buffer.from(JSON.stringify(full), "utf8"));
  const sig = b64urlEncode(crypto.createHmac("sha256", secret).update(payloadB64).digest());
  return `${payloadB64}.${sig}`;
}

/** ✅ Origin PUBLIC (anti localhost) */
function pickPublicOrigin(fallbackOrigin: string) {
  const raw =
    process.env.NEXT_PUBLIC_APP_URL ||
    process.env.PUBLIC_APP_URL ||
    process.env.APP_URL ||
    fallbackOrigin;

  return String(raw || "").replace(/\/+$/, "");
}

/** ✅ QR PNG server-side (qualité print + quiet zone) */
async function attachQrPng<T extends { qr_url: string | null }>(items: T[]) {
  // ✅ défaut plus robuste à l'impression
  const size = Number(process.env.BULLETIN_QR_PNG_SIZE || "600");
  const margin = Number(process.env.BULLETIN_QR_PNG_MARGIN || "2");
  const ecl =
    (process.env.BULLETIN_QR_PNG_ECL || "M") as "L" | "M" | "Q" | "H";

  return await Promise.all(
    items.map(async (it) => {
      if (!it.qr_url) return { ...it, qr_png: null as string | null };

      try {
        const png = await QRCode.toDataURL(it.qr_url, {
          width: size,
          margin, // ✅ quiet zone (CRITIQUE)
          errorCorrectionLevel: ecl,
        });
        return { ...it, qr_png: png || null };
      } catch (e) {
        return { ...it, qr_png: null as string | null };
      }
    })
  );
}

function computeBulletinKey(p: {
  instId: string;
  classId: string;
  studentId: string;
  academicYear: string | null;
  periodFrom: string | null;
  periodTo: string | null;
  periodLabel: string | null;
}) {
  const raw = [
    p.instId,
    p.classId,
    p.studentId,
    p.academicYear ?? "",
    p.periodFrom ?? "",
    p.periodTo ?? "",
    p.periodLabel ?? "",
  ].join("|");

  return crypto.createHash("sha256").update(raw).digest("hex");
}

/**
 * ✅ Génère un QR URL COURT (/v/[code]) en stockant un mapping en DB.
 * ✅ Fallback automatique vers l'ancien token si la table n'est pas prête.
 */
async function addQrToItems<T extends { student_id: string }>(
  srv: SupabaseClient,
  items: T[],
  opts: {
    origin: string;
    institutionId: string;
    classId: string;
    classAcademicYear?: string | null;
    periodMeta: {
      from: string | null;
      to: string | null;
      code?: string | null;
      label?: string | null;
      short_label?: string | null;
      academic_year?: string | null;
    };
  }
): Promise<
  (T & {
    qr_mode: "short" | "token" | null;
    qr_code: string | null;
    qr_token: string | null;
    qr_url: string | null;
  })[]
> {
  const academicYear = opts.periodMeta.academic_year ?? opts.classAcademicYear ?? null;

  const periodLabel =
    opts.periodMeta.short_label ?? opts.periodMeta.label ?? opts.periodMeta.code ?? null;

const snapFor = (row: any) => {
  const g = cleanNumber((row as any)?.general_avg, 4);
  const a = cleanNumber((row as any)?.annual_avg, 4);
  if (g === null && a === null) return null;
  return { g, a };
};


  // On essaie le mode "short" par défaut (idéal pour le scan)
  const envMode = String(process.env.BULLETIN_QR_MODE || "short").toLowerCase();
  const preferShort = envMode !== "token";

  // 1) Test "short" une fois (évite de spammer les erreurs si table absente)
  let shortSupported = false;
  let firstShort: { student_id: string; code: string } | null = null;

  if (preferShort && items.length) {
    try {
      const it0 = items[0];
      const bulletinKey = computeBulletinKey({
        instId: opts.institutionId,
        classId: opts.classId,
        studentId: it0.student_id,
        academicYear,
        periodFrom: opts.periodMeta.from ?? null,
        periodTo: opts.periodMeta.to ?? null,
        periodLabel,
      });

      const code = await getOrCreateBulletinShortCode(srv, {
        bulletinKey,
        payload: {
          instId: opts.institutionId,
          classId: opts.classId,
          studentId: it0.student_id,
          academicYear,
          periodFrom: opts.periodMeta.from ?? null,
          periodTo: opts.periodMeta.to ?? null,
          periodLabel,
          periodShortLabel: opts.periodMeta.short_label ?? null,
          s: snapFor(it0),
        },
        expiresAt: null,
      });

      shortSupported = !!code;
      if (shortSupported) firstShort = { student_id: it0.student_id, code };
    } catch {
      shortSupported = false;
    }
  }

  // 2) Mode short si supporté
  if (shortSupported) {
    return await Promise.all(
      items.map(async (it) => {
        try {
          let code: string;

          if (firstShort && firstShort.student_id === it.student_id) {
            code = firstShort.code;
          } else {
            const bulletinKey = computeBulletinKey({
              instId: opts.institutionId,
              classId: opts.classId,
              studentId: it.student_id,
              academicYear,
              periodFrom: opts.periodMeta.from ?? null,
              periodTo: opts.periodMeta.to ?? null,
              periodLabel,
            });

            code = await getOrCreateBulletinShortCode(srv, {
              bulletinKey,
              payload: {
                instId: opts.institutionId,
                classId: opts.classId,
                studentId: it.student_id,
                academicYear,
                periodFrom: opts.periodMeta.from ?? null,
                periodTo: opts.periodMeta.to ?? null,
                periodLabel,
                periodShortLabel: opts.periodMeta.short_label ?? null,
                s: snapFor(it),
              },
              expiresAt: null,
            });
          }

          const url = code ? `${opts.origin}${BULLETIN_VERIFY_SHORT_PREFIX}/${code}` : null;

          return {
            ...it,
            qr_mode: code ? ("short" as const) : null,
            qr_code: code || null,
            qr_token: null,
            qr_url: url,
          };
        } catch {
          // fallback token (si possible)
          const token = signBulletinQRToken({
            instId: opts.institutionId,
            classId: opts.classId,
            studentId: it.student_id,
            academicYear,
            periodFrom: opts.periodMeta.from ?? null,
            periodTo: opts.periodMeta.to ?? null,
            periodLabel,
            periodShortLabel: opts.periodMeta.short_label ?? null,
            s: snapFor(it),
          });

          const url = token
            ? `${opts.origin}${BULLETIN_VERIFY_LEGACY_PATH}?t=${encodeURIComponent(token)}`
            : null;

          return {
            ...it,
            qr_mode: token ? ("token" as const) : null,
            qr_code: null,
            qr_token: token,
            qr_url: url,
          };
        }
      })
    );
  }

  // 3) Fallback token pour tous
  return items.map((it) => {
    const token = signBulletinQRToken({
      instId: opts.institutionId,
      classId: opts.classId,
      studentId: it.student_id,
      academicYear,
      periodFrom: opts.periodMeta.from ?? null,
      periodTo: opts.periodMeta.to ?? null,
      periodLabel,
    });

    const url = token
      ? `${opts.origin}${BULLETIN_VERIFY_LEGACY_PATH}?t=${encodeURIComponent(token)}`
      : null;

    return {
      ...it,
      qr_mode: token ? ("token" as const) : null,
      qr_code: null,
      qr_token: token,
      qr_url: url,
    };
  });
}

/* ───────── helper : récup user_roles + institution ───────── */
async function getAdminAndInstitution(
  supabase: Awaited<ReturnType<typeof getSupabaseServerClient>>
) {
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return { error: "UNAUTHENTICATED" as const };
  }

  const { data: roleRow, error: roleErr } = await supabase
    .from("user_roles")
    .select("institution_id, role")
    .eq("profile_id", user.id)
    .in("role", ["admin", "super_admin"])
    .limit(1)
    .maybeSingle();

  if (roleErr || !roleRow) {
    return { error: "PROFILE_NOT_FOUND" as const };
  }

  const role = roleRow.role as Role;
  if (!["super_admin", "admin"].includes(role)) {
    return { error: "FORBIDDEN" as const };
  }

  const institutionId = roleRow.institution_id;
  if (!institutionId) {
    return { error: "NO_INSTITUTION" as const };
  }

  return { user, institutionId, role };
}

/* ───────── helper : rang par matière (subject_rank) ───────── */
function applySubjectRanks(items: any[]) {
  if (!items || !items.length) return;

  type Entry = { index: number; avg: number; subject_id: string };
  const bySubject = new Map<string, Entry[]>();

  items.forEach((item, idx) => {
    const perSubject = item.per_subject as any[] | undefined;
    if (!Array.isArray(perSubject)) return;

    perSubject.forEach((ps) => {
      const avg =
        typeof ps.avg20 === "number" && Number.isFinite(ps.avg20) ? ps.avg20 : null;
      const sid = ps.subject_id as string | undefined;
      if (!sid || avg === null) return;

      const arr = bySubject.get(sid) || [];
      arr.push({ index: idx, avg, subject_id: sid });
      bySubject.set(sid, arr);
    });
  });

  bySubject.forEach((entries, subjectId) => {
    entries.sort((a, b) => b.avg - a.avg);

    let lastAvg: number | null = null;
    let currentRank = 0;
    let position = 0;

    for (const { index, avg } of entries) {
      position += 1;
      if (lastAvg === null || avg !== lastAvg) {
        currentRank = position;
        lastAvg = avg;
      }

      const perSubject = items[index].per_subject as any[];
      if (!Array.isArray(perSubject)) continue;

      const cell = perSubject.find((ps: any) => ps.subject_id === subjectId);
      if (cell) (cell as any).subject_rank = currentRank;
    }
  });
}

/* ───────── helper : rang par sous-matière (component_rank) ───────── */
function applySubjectComponentRanks(items: any[]) {
  if (!items || !items.length) return;

  type Entry = { index: number; avg: number; component_id: string };
  const byComponent = new Map<string, Entry[]>();

  items.forEach((item, idx) => {
    const perComp = item.per_subject_components as any[] | undefined;
    if (!Array.isArray(perComp)) return;

    perComp.forEach((psc) => {
      const avg =
        typeof psc.avg20 === "number" && Number.isFinite(psc.avg20) ? psc.avg20 : null;
      const cid = psc.component_id as string | undefined;
      if (!cid || avg === null) return;

      const arr = byComponent.get(cid) || [];
      arr.push({ index: idx, avg, component_id: cid });
      byComponent.set(cid, arr);
    });
  });

  byComponent.forEach((entries, componentId) => {
    entries.sort((a, b) => b.avg - a.avg);

    let lastAvg: number | null = null;
    let currentRank = 0;
    let position = 0;

    for (const { index, avg } of entries) {
      position += 1;
      if (lastAvg === null || avg !== lastAvg) {
        currentRank = position;
        lastAvg = avg;
      }

      const perComp = items[index].per_subject_components as any[] | undefined;
      if (!Array.isArray(perComp)) continue;

      const cell = perComp.find((psc: any) => psc.component_id === componentId);
      if (cell) (cell as any).component_rank = currentRank;
    }
  });
}

/* ───────── helper : base64 data url (node) ───────── */
async function blobToPngDataUrl(blob: any): Promise<string | null> {
  try {
    if (!blob || typeof blob.arrayBuffer !== "function") return null;
    const ab = await blob.arrayBuffer();
    const b64 = Buffer.from(ab).toString("base64");
    if (!b64) return null;
    return `data:image/png;base64,${b64}`;
  } catch {
    return null;
  }
}

function chunk<T>(arr: T[], size: number) {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/* ───────── helper : signatures profs (data url) ───────── */
async function getTeacherSignaturesAsDataUrl(
  srv: SupabaseClient,
  institutionId: string,
  teacherIds: string[]
): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const unique = Array.from(new Set(teacherIds.filter((x) => !!x && isUuid(x))));

  if (!unique.length) return out;

  const { data: sigRows, error: sigErr } = await srv
    .from("teacher_signatures")
    .select("teacher_id, storage_path")
    .eq("institution_id", institutionId)
    .in("teacher_id", unique);

  if (sigErr || !sigRows?.length) return out;

  const rows = (sigRows as any[])
    .map((r) => ({
      teacher_id: String(r.teacher_id || ""),
      storage_path: String(r.storage_path || ""),
    }))
    .filter((r) => isUuid(r.teacher_id) && r.storage_path);

  if (!rows.length) return out;

  // ⚠️ éviter trop de downloads en parallèle
  for (const pack of chunk(rows, 8)) {
    await Promise.all(
      pack.map(async (r) => {
        try {
          const { data, error } = await srv.storage.from("signatures").download(r.storage_path);
          if (error || !data) return;
          const url = await blobToPngDataUrl(data);
          if (!url) return;
          out.set(r.teacher_id, url);
        } catch {
          // ignore
        }
      })
    );
  }

  return out;
}

/* ───────── helper : prof par matière + teacher_id + teacher_name ───────── */
async function attachTeachersToSubjects(
  supabase: Awaited<ReturnType<typeof getSupabaseServerClient>>,
  srv: Awaited<ReturnType<typeof getSupabaseServiceClient>>,
  items: any[],
  evals: EvalRow[],
  subjectIds: string[],
  institutionId: string,
  classId: string,
  dateFrom?: string | null,
  dateTo?: string | null
) {
  if (!items.length || !subjectIds.length) return;

  // ✅ subject -> teacher_id
  const teacherIdBySubject = new Map<string, string>();
  const lastEvalDateBySubject = new Map<string, string>();

  /* ── A. Priorité : grade_evaluations.teacher_id (dernière date) ── */
  if (evals.length) {
    for (const ev of evals) {
      if (!ev.subject_id || !ev.teacher_id) continue;
      const sid = String(ev.subject_id);
      const tid = String(ev.teacher_id);
      const date = String(ev.eval_date || "");

      const prev = lastEvalDateBySubject.get(sid) || "";
      if (!prev || (date && date > prev)) {
        lastEvalDateBySubject.set(sid, date);
        teacherIdBySubject.set(sid, tid);
      }
    }
  }

  /* ── B. Fallback : institution_subjects + class_teachers ── */
  const missingSubjectIds = subjectIds.filter((sid) => !teacherIdBySubject.has(sid));

  if (missingSubjectIds.length) {
    const { data: instSubs, error: instErr } = await srv
      .from("institution_subjects")
      .select("id, subject_id")
      .eq("institution_id", institutionId)
      .in("subject_id", missingSubjectIds);

    if (!instErr && instSubs?.length) {
      const instIds: string[] = [];
      const subjectIdByInstId = new Map<string, string>();

      (instSubs as any[]).forEach((row) => {
        const sid = String(row.subject_id || "");
        const instId = String(row.id || "");
        if (!sid || !instId) return;
        instIds.push(instId);
        subjectIdByInstId.set(instId, sid);
      });

      if (instIds.length) {
        let ctQuery = srv
          .from("class_teachers")
          .select("subject_id, teacher_id, start_date, end_date")
          .eq("institution_id", institutionId)
          .eq("class_id", classId)
          .in("subject_id", instIds);

        const pivot = dateTo || dateFrom || null;
        if (pivot) {
          ctQuery = ctQuery
            .or(`end_date.is.null,end_date.gte.${pivot}`)
            .or(`start_date.is.null,start_date.lte.${pivot}`);
        } else {
          ctQuery = ctQuery.is("end_date", null);
        }

        const { data: ctData, error: ctErr } = await ctQuery;

        if (!ctErr && ctData?.length) {
          // on trie pour privilégier l'affectation la plus récente
          const rows = (ctData as any[]).slice().sort((a, b) => {
            const asd = String(a.start_date || "");
            const bsd = String(b.start_date || "");
            return bsd.localeCompare(asd);
          });

          for (const row of rows) {
            const instSubId = String(row.subject_id || "");
            const sid = subjectIdByInstId.get(instSubId);
            const tid = row.teacher_id ? String(row.teacher_id) : "";
            if (!sid || !tid) continue;
            if (teacherIdBySubject.has(sid)) continue;
            teacherIdBySubject.set(sid, tid);
          }
        }
      }
    }
  }

  if (!teacherIdBySubject.size) return;

  const teacherIds = Array.from(new Set(Array.from(teacherIdBySubject.values()).filter((x) => !!x)));
  const nameById = new Map<string, string>();

  if (teacherIds.length) {
    const { data: profs, error: profErr } = await supabase
      .from("profiles")
      .select("id, display_name")
      .in("id", teacherIds);

    if (!profErr && profs?.length) {
      (profs as any[]).forEach((p) => {
        const id = String(p.id || "");
        const dn = String(p.display_name || "").trim();
        if (id && dn) nameById.set(id, dn);
      });
    }
  }

  for (const item of items) {
    const perSubject = item.per_subject as any[] | undefined;
    if (!Array.isArray(perSubject)) continue;

    perSubject.forEach((ps) => {
      const sid = ps.subject_id as string | undefined;
      if (!sid) return;

      const tid = teacherIdBySubject.get(sid) ?? null;
      const tname = tid ? nameById.get(tid) ?? null : null;

      (ps as any).teacher_id = tid;
      (ps as any).teacher_name = tname;
    });
  }
}

/* ───────── fallback bilans (si pas de config DB) ───────── */

function buildFallbackGroups(opts: {
  subjectIds: string[];
  subjectInfoById: Map<string, { name: string; code: string }>;
  coeffBySubject: Map<string, { coeff: number; include: boolean }>;
}): BulletinSubjectGroup[] {
  const { subjectIds, subjectInfoById, coeffBySubject } = opts;

  const letters: string[] = [];
  const sciences: string[] = [];
  const autres: string[] = [];

  for (const sid of subjectIds) {
    const meta = subjectInfoById.get(sid) || { name: "", code: "" };
    const name = meta.name;
    const code = meta.code;

    // ✅ Règle blindée : AUTRES = tout ce qui n'est pas LETTRES et pas SCIENCES
    if (isScienceSubject(name, code)) sciences.push(sid);
    else if (isLettersSubject(name, code)) letters.push(sid);
    else autres.push(sid);
  }

  const mkGroup = (p: {
    id: string;
    code: string;
    label: string;
    order_index: number;
    sids: string[];
  }): BulletinSubjectGroup => {
    const items: BulletinSubjectGroupItem[] = p.sids.map((sid, idx) => {
      const meta = subjectInfoById.get(sid) || { name: "", code: "" };
      const subjectName = meta.name || meta.code || "Matière";
      return {
        id: `virt-${p.code}-${sid}`,
        group_id: p.id,
        subject_id: sid,
        subject_name: subjectName,
        order_index: idx + 1,
        subject_coeff_override: null,
        is_optional: false,
      };
    });

    // annual_coeff = somme des coeffs des matières du groupe (logique "bulletin officiel")
    let sumCoeff = 0;
    for (const sid of p.sids) {
      const info = coeffBySubject.get(sid);
      const c = info ? Number(info.coeff ?? 1) : 1;
      if (Number.isFinite(c) && c > 0) sumCoeff += c;
    }

    return {
      id: p.id,
      code: p.code,
      label: p.label,
      short_label: null,
      order_index: p.order_index,
      is_active: true,
      annual_coeff: cleanCoeff(sumCoeff || 1),
      items,
    };
  };

  const groups: BulletinSubjectGroup[] = [
    mkGroup({
      id: "fallback-letters",
      code: "BILAN_LETTRES",
      label: "BILAN LETTRES",
      order_index: 1,
      sids: letters,
    }),
    mkGroup({
      id: "fallback-sciences",
      code: "BILAN_SCIENCES",
      label: "BILAN SCIENCES",
      order_index: 2,
      sids: sciences,
    }),
    mkGroup({
      id: "fallback-autres",
      code: "BILAN_AUTRES",
      label: "BILAN AUTRES",
      order_index: 3,
      sids: autres,
    }),
  ];

  // On supprime les groupes vides (mais on garde l’ordre)
  return groups.filter((g) => g.items.length > 0);
}

/* ───────── helper annuel : rang avec ex aequo ───────── */
function buildRankMapFromAverageMap(avgByStudent: Map<string, number | null>) {
  const rows: { student_id: string; avg: number }[] = [];
  for (const [sid, avg] of avgByStudent.entries()) {
    if (typeof avg === "number" && Number.isFinite(avg)) rows.push({ student_id: sid, avg });
  }
  rows.sort((a, b) => b.avg - a.avg);

  const rankByStudent = new Map<string, number>();
  let lastAvg: number | null = null;
  let currentRank = 0;
  let position = 0;

  for (const r of rows) {
    position += 1;
    if (lastAvg === null || r.avg !== lastAvg) {
      currentRank = position;
      lastAvg = r.avg;
    }
    rankByStudent.set(r.student_id, currentRank);
  }

  return rankByStudent;
}

async function loadBulletinNcOverrideMap(
  srv: SupabaseClient,
  opts: {
    institutionId: string;
    classId: string;
    academicYear: string | null | undefined;
    from: string | null | undefined;
    to: string | null | undefined;
    scope: "period" | "annual";
  }
): Promise<Map<string, BulletinNcOverrideRow>> {
  const out = new Map<string, BulletinNcOverrideRow>();

  const academicYear = String(opts.academicYear || "").trim();
  const from = String(opts.from || "").trim();
  const to = String(opts.to || "").trim();

  if (!opts.institutionId || !opts.classId || !academicYear || !from || !to) {
    return out;
  }

  try {
    const { data, error } = await srv
      .from("bulletin_nc_overrides")
      .select(
        "id, student_id, academic_year, period_from, period_to, scope, is_nc, reason, missing_subjects_snapshot"
      )
      .eq("institution_id", opts.institutionId)
      .eq("class_id", opts.classId)
      .eq("academic_year", academicYear)
      .eq("period_from", from)
      .eq("period_to", to)
      .eq("scope", opts.scope)
      .eq("is_nc", true);

    if (error) {
      // Non cassant : si la migration n'est pas encore exécutée, le bulletin reste lisible.
      console.warn("[bulletin] nc overrides indisponibles", {
        scope: opts.scope,
        from,
        to,
        error,
      });
      return out;
    }

    for (const row of (data || []) as any[]) {
      const sid = String(row.student_id || "");
      if (!sid) continue;
      out.set(sid, {
        id: String(row.id),
        student_id: sid,
        scope: String(row.scope || opts.scope),
        is_nc: row.is_nc === true,
        reason: row.reason ?? null,
        missing_subjects_snapshot: row.missing_subjects_snapshot ?? [],
        period_from: row.period_from ?? from,
        period_to: row.period_to ?? to,
        academic_year: row.academic_year ?? academicYear,
      });
    }

    return out;
  } catch (error) {
    console.warn("[bulletin] nc overrides exception", {
      scope: opts.scope,
      from,
      to,
      error,
    });
    return out;
  }
}

function applyPeriodNcOverridesToItems(
  items: any[],
  overrides: Map<string, BulletinNcOverrideRow>
) {
  if (!items.length || !overrides.size) return;

  for (const item of items) {
    const sid = String(item?.student_id || "");
    const override = overrides.get(sid);
    if (!override) continue;

    const before =
      typeof item.general_avg === "number" && Number.isFinite(item.general_avg)
        ? item.general_avg
        : null;

    item.admin_forced_nc = true;
    item.admin_nc_override = {
      id: override.id,
      scope: "period",
      reason: override.reason,
      missing_subjects_snapshot: override.missing_subjects_snapshot ?? [],
    };
    item.general_avg_before_admin_nc = before;

    // Décision admin : NC au général uniquement.
    // Les moyennes par matière restent intactes.
    item.general_avg = null;
    item.rank = null;
    item.general_avg_is_complete = false;
    item.general_avg_status = "admin_nc";
  }
}

/* ───────── GET /api/admin/grades/bulletin ───────── */
export async function GET(req: NextRequest) {
  const supabase = await getSupabaseServerClient();
  const srv = getSupabaseServiceClient();
  const srvClient = srv as unknown as SupabaseClient;

  const ctx = await getAdminAndInstitution(supabase);

  if ("error" in ctx) {
    const status =
      ctx.error === "UNAUTHENTICATED"
        ? 401
        : ctx.error === "FORBIDDEN"
        ? 403
        : 400;
    return NextResponse.json({ ok: false, error: ctx.error }, { status });
  }

  const { institutionId } = ctx;

  const { searchParams } = new URL(req.url);
  const classId = searchParams.get("class_id");
  const dateFrom = searchParams.get("from");
  const dateTo = searchParams.get("to");

  if (!classId) {
    return NextResponse.json({ ok: false, error: "MISSING_CLASS_ID" }, { status: 400 });
  }

  // ✅ class_id non-null (utile dans les closures)
  const classIdStr: string = classId;

  // ✅ origin PUBLIC (anti localhost)
  const origin = pickPublicOrigin(req.nextUrl.origin);

  // ✅ QR considéré "activable" si on peut faire short (service role) ou token (secret)
  const qrEnabled = !!(process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.BULLETIN_QR_SECRET);
  const qrMode = String(process.env.BULLETIN_QR_MODE || "short").toLowerCase();

  /* 1) Vérifier que la classe appartient à l'établissement + récupérer prof principal */
  const { data: cls, error: clsErr } = await supabase
    .from("classes")
    .select("id, label, code, institution_id, academic_year, head_teacher_id, level, official_track_code")
    .eq("id", classId)
    .maybeSingle();

  if (clsErr) {
    return NextResponse.json({ ok: false, error: "CLASS_ERROR" }, { status: 500 });
  }
  if (!cls) {
    return NextResponse.json({ ok: false, error: "CLASS_NOT_FOUND" }, { status: 404 });
  }

  const classRow = cls as ClassRow;

  if (!classRow.institution_id) {
    return NextResponse.json({ ok: false, error: "CLASS_NO_INSTITUTION" }, { status: 400 });
  }
  if (classRow.institution_id !== institutionId) {
    return NextResponse.json({ ok: false, error: "CLASS_FORBIDDEN" }, { status: 403 });
  }

  const bulletinLevel = normalizeBulletinLevel(classRow.level);
  const coeffLevelCandidates = buildCoeffLevelCandidates(classRow, bulletinLevel);
  const allowSubjectComponents = allowSubjectComponentsForBulletinLevel(bulletinLevel);

  /* ✅ lire l'option établissement : bulletin_signatures_enabled (institutions) */
  let bulletinSignaturesEnabled = false;
  let institutionMeta: InstitutionMeta = { id: institutionId };
  {
    const { data: instRow } = await srvClient
      .from("institutions")
      .select("id, name, code_unique, acronym, bulletin_signatures_enabled, settings_json")
      .eq("id", institutionId)
      .maybeSingle();

    institutionMeta = {
      id: String((instRow as any)?.id || institutionId),
      name: (instRow as any)?.name ?? null,
      code_unique: (instRow as any)?.code_unique ?? null,
      acronym: (instRow as any)?.acronym ?? null,
    };

    const col = (instRow as any)?.bulletin_signatures_enabled;
    if (typeof col === "boolean") bulletinSignaturesEnabled = col;
    else
      bulletinSignaturesEnabled = Boolean(
        (instRow as any)?.settings_json?.bulletin_signatures_enabled ?? false
      );
  }

  const isCSCA = isCSCAInstitution(institutionMeta);

  // 1a) Lookup du professeur principal (facultatif)
  let headTeacher: HeadTeacherRow | null = null;
  if (classRow.head_teacher_id) {
    const { data: ht, error: htErr } = await supabase
      .from("profiles")
      .select("id, display_name, phone, email")
      .eq("id", classRow.head_teacher_id)
      .maybeSingle();

    if (htErr) {
      // ignore
    } else if (ht) headTeacher = ht as HeadTeacherRow;
  }

  /* 1bis) Retrouver éventuellement la période de bulletin (grade_periods) + son coeff */
  let periodMeta: {
    id?: string | null;
    from: string | null;
    to: string | null;
    code?: string | null;
    label?: string | null;
    short_label?: string | null;
    academic_year?: string | null;
    coeff?: number | null;
  } = { id: null, from: dateFrom, to: dateTo };

  if (dateFrom && dateTo) {
    // ⚠️ évite maybeSingle() (erreur si doublons) -> on prend le 1er match
    const { data: gpRows, error: gpErr } = await supabase
      .from("grade_periods")
      .select("id, academic_year, code, label, short_label, start_date, end_date, coeff")
      .eq("institution_id", institutionId)
      .eq("start_date", dateFrom)
      .eq("end_date", dateTo)
      .order("start_date", { ascending: true })
      .limit(1);

    const gp = (gpRows && gpRows.length ? (gpRows[0] as any) : null) as any;

    if (gpErr) {
      // ignore
    } else if (gp) {
      periodMeta = {
        id: gp.id ?? null,
        from: dateFrom,
        to: dateTo,
        code: gp.code ?? null,
        label: gp.label ?? null,
        short_label: gp.short_label ?? null,
        academic_year: gp.academic_year ?? null,
        coeff: gp.coeff === null || gp.coeff === undefined ? null : cleanCoeff(gp.coeff),
      };
    }
  }

  /* ✅ 1ter) Déterminer dernière période + flags (annual only on last) */
  const academicYearForPeriods = periodMeta.academic_year ?? classRow.academic_year ?? null;

  let periodsForYear: GradePeriodRow[] = [];
  let periodsDefined = false;
  let lastPeriod: GradePeriodRow | null = null;
  let isLastPeriod = false;

  {
    let q = supabase
      .from("grade_periods")
      .select("id, academic_year, code, label, short_label, start_date, end_date, coeff")
      .eq("institution_id", institutionId);

    if (academicYearForPeriods) q = q.eq("academic_year", academicYearForPeriods);

    const { data: pData, error: pErr } = await q.order("start_date", { ascending: true });

    if (!pErr && pData?.length) {
      periodsForYear = (pData as any[]) as GradePeriodRow[];
      periodsDefined = periodsForYear.length > 0;

      // dernier = max end_date (fallback start_date)
      const sorted = periodsForYear.slice().sort((a, b) => {
        const ae = String(a.end_date || "");
        const be = String(b.end_date || "");
        if (ae !== be) return ae.localeCompare(be);
        const asd = String(a.start_date || "");
        const bsd = String(b.start_date || "");
        return asd.localeCompare(bsd);
      });

      lastPeriod = sorted.length ? sorted[sorted.length - 1] : null;

      isLastPeriod =
        !!lastPeriod &&
        !!dateFrom &&
        !!dateTo &&
        String(lastPeriod.start_date) === String(dateFrom) &&
        String(lastPeriod.end_date) === String(dateTo);
    }
  }

  const periodResponse = {
    ...periodMeta,
    periods_defined: periodsDefined,
    is_last: isLastPeriod,
    last_period: lastPeriod
      ? {
          from: lastPeriod.start_date,
          to: lastPeriod.end_date,
          code: lastPeriod.code ?? null,
          label: lastPeriod.label ?? null,
          short_label: lastPeriod.short_label ?? null,
          academic_year: lastPeriod.academic_year ?? academicYearForPeriods ?? null,
          coeff:
            lastPeriod.coeff === null || lastPeriod.coeff === undefined
              ? null
              : cleanCoeff(lastPeriod.coeff),
        }
      : null,
  };

  /* 2) Récupérer les élèves
   *
   * ✅ Règle métier Mon Cahier :
   * Pour le bulletin actuel, le PV du conseil de classe, les statistiques et
   * la fiche annuelle, la liste de classe doit être la même que dans le cahier
   * des notes : uniquement les inscriptions actives.
   *
   * Les élèves retirés restent dans class_enrollments pour l’historique, mais
   * ils ne doivent plus entrer dans les effectifs, rangs, tops, PV, conduite,
   * QR/bulletins générés depuis la classe courante.
   *
   * Option non cassante : si un jour on veut volontairement sortir un bulletin
   * historique d’élèves présents sur une ancienne période, on pourra appeler
   * cette API avec active_only=false. Par défaut : active_only=true.
   */
  const activeOnlyParam = String(searchParams.get("active_only") || "").trim().toLowerCase();
  const activeOnly = !(activeOnlyParam === "false" || activeOnlyParam === "0" || activeOnlyParam === "no");
  const hasDateFilter = !!dateFrom || !!dateTo;

  let enrollQuery = supabase
    .from("class_enrollments")
    .select(
      `
      student_id,
      start_date,
      end_date,
      students(
        matricule,
        first_name,
        last_name,
        full_name,
        photo_url,
        gender,
        birthdate,
        birth_place,
        nationality,
        regime,
        is_repeater,
        is_boarder,
        is_affecte
      )
    `
    )
    .eq("class_id", classId);

  if (activeOnly) {
    enrollQuery = enrollQuery.is("end_date", null);
  } else if (!hasDateFilter) {
    enrollQuery = enrollQuery.is("end_date", null);
  } else {
    // Mode historique explicite : présent au moins une partie de la période.
    if (dateFrom) enrollQuery = enrollQuery.or(`end_date.gte.${dateFrom},end_date.is.null`);
    if (dateTo) enrollQuery = enrollQuery.lte("start_date", dateTo);
  }

  enrollQuery = enrollQuery.order("student_id", { ascending: true });

  const { data: csData, error: csErr } = await enrollQuery;

  if (csErr) {
    return NextResponse.json({ ok: false, error: "CLASS_STUDENTS_ERROR" }, { status: 500 });
  }

  // ✅ Déduplication défensive : évite les doublons si une correction d’import
  // a laissé plusieurs lignes d’inscription pour le même élève.
  const classStudentMap = new Map<string, ClassStudentRow>();
  for (const row of (csData || []) as ClassStudentRow[]) {
    const sid = String(row.student_id || "").trim();
    if (!sid) continue;
    if (!classStudentMap.has(sid)) classStudentMap.set(sid, row);
  }

  const classStudents = Array.from(classStudentMap.values());
  const studentIds = classStudents.map((cs) => cs.student_id);

  const bulletinAcademicYear =
    periodMeta.academic_year ?? classRow.academic_year ?? academicYearForPeriods ?? null;

  const periodNcOverrideMap =
    dateFrom && dateTo
      ? await loadBulletinNcOverrideMap(srvClient, {
          institutionId,
          classId: classRow.id,
          academicYear: bulletinAcademicYear,
          from: dateFrom,
          to: dateTo,
          scope: "period",
        })
      : new Map<string, BulletinNcOverrideRow>();

  // Si aucun élève : on renvoie structure minimale (non cassant)
  if (!classStudents.length) {
    return NextResponse.json({
      ok: true,
      qr: {
        enabled: qrEnabled,
        mode: qrMode,
        verify_path: BULLETIN_VERIFY_SHORT_PREFIX,
        legacy_verify_path: BULLETIN_VERIFY_LEGACY_PATH,
      },
      signatures: { enabled: bulletinSignaturesEnabled },
      class: {
        id: classRow.id,
        label: classRow.label || classRow.code || "Classe",
        code: classRow.code || null,
        academic_year: classRow.academic_year || null,
        level: classRow.level || null,
        official_track_code: classRow.official_track_code || null,
        coefficient_level: coeffLevelCandidates[0] || bulletinLevel || null,
        bulletin_level: bulletinLevel,
        head_teacher: headTeacher
          ? {
              id: headTeacher.id,
              display_name: headTeacher.display_name || null,
              phone: headTeacher.phone || null,
              email: headTeacher.email || null,
            }
          : null,
      },
      period: periodResponse,
      subjects: [],
      subject_groups: [],
      subject_components: [],
      items: [],
    });
  }

  /* ───────── Conduite (coef 1) — helpers ───────── */
  const clamp20 = (n: number) => Math.max(0, Math.min(20, n));

  async function fetchConductAverageMap(
    from: string,
    to: string
  ): Promise<Map<string, number | null>> {
    const out = new Map<string, number | null>();
    studentIds.forEach((sid) => out.set(sid, null));

    try {
      const qs = new URLSearchParams({ class_id: classIdStr, from, to });
      const conductAcademicYear = String(periodMeta.academic_year || classRow.academic_year || "").trim();
      const conductPeriodCode = String(periodMeta.code || "").trim();
      if (conductAcademicYear) qs.set("academic_year", conductAcademicYear);
      if (conductPeriodCode) qs.set("period_code", conductPeriodCode);
      const cookie = req.headers.get("cookie") ?? "";

      const r = await fetch(
        `${req.nextUrl.origin}/api/admin/conduite/averages?${qs.toString()}`,
        {
          method: "GET",
          headers: cookie ? { cookie } : {},
          cache: "no-store",
        }
      );

      if (!r.ok) return out;

      const j: any = await r.json();

      // tolère plusieurs shapes: {items:[...]}, {data:[...]} ou tableau direct
      const arr: any[] = Array.isArray(j)
        ? j
        : Array.isArray(j?.items)
          ? j.items
          : Array.isArray(j?.data)
            ? j.data
            : [];

      for (const it of arr) {
        const sid = String(it?.student_id ?? "");
        if (!sid) continue;

        // "total" attendu (note /20). On accepte aussi "avg" ou "value" si présent.
        const raw =
          it?.total ?? it?.avg ?? it?.value ?? it?.score ?? it?.note ?? null;

        const total = Number(raw);
        if (!Number.isFinite(total)) continue;

        out.set(sid, clamp20(total));
      }
    } catch {
      // ne casse jamais le bulletin si la conduite échoue
    }

    return out;
  }

  /* 3) Coefficients bulletin par matière (tolérant sur le niveau) */
  // ✅ IMPORTANT : les coefficients officiels doivent être lus avec le client service.
  // Sur l'endpoint admin, le client session peut être limité par RLS selon le contexte
  // navigateur / service worker, ce qui vide coeffBySubject et fait retomber le bulletin
  // à coeff_bulletin = 1 partout. Le client service est déjà utilisé plus bas pour les
  // affectations et les politiques : on l'utilise aussi ici pour une lecture fiable.
  const { data: coeffAllData, error: coeffAllErr } = await srvClient
    .from("institution_subject_coeffs")
    .select("subject_id, coeff, include_in_average, level")
    .eq("institution_id", institutionId);

  if (coeffAllErr) {
    console.warn("[bulletin] institution_subject_coeffs indisponible", coeffAllErr);
  }

  const coeffBySubject = new Map<string, { coeff: number; include: boolean }>();
  const subjectIdsFromConfig = new Set<string>();
  const coeffRowsBySubject = new Map<string, SubjectCoeffRow[]>();

  for (const row of (coeffAllData || []) as SubjectCoeffRow[]) {
    const sid = String(row.subject_id || "");
    if (!sid || !isUuid(sid)) continue;

    subjectIdsFromConfig.add(sid);

    const arr = coeffRowsBySubject.get(sid) || [];
    arr.push(row);
    coeffRowsBySubject.set(sid, arr);
  }

  const officialCoeffLevel = normalizeCoeffLevelKey(classRow.official_track_code);
  const requiresStrictOfficialCoeffs =
    !!officialCoeffLevel && STRICT_OFFICIAL_COEFF_LEVELS.has(officialCoeffLevel);

  if (requiresStrictOfficialCoeffs) {
    const configuredSubjectsForOfficialLevel = new Set<string>();

    for (const row of (coeffAllData || []) as SubjectCoeffRow[]) {
      const sid = String(row.subject_id || "");
      if (!sid || !isUuid(sid)) continue;
      if (normalizeStoredLevel(row.level) !== officialCoeffLevel) continue;
      configuredSubjectsForOfficialLevel.add(sid);
    }

    if (configuredSubjectsForOfficialLevel.size === 0) {
      return NextResponse.json(
        {
          ok: false,
          error: "MISSING_OFFICIAL_TRACK_COEFFS",
          message:
            "Les coefficients de la série officielle de cette classe ne sont pas configurés. Configurez d'abord les coefficients dans Paramètres avant de générer le bulletin.",
          official_track_code: officialCoeffLevel,
          class_label: classRow.label || classRow.code || null,
        },
        { status: 409 }
      );
    }
  }

  for (const [sid, rows] of coeffRowsBySubject.entries()) {
    const best = pickBestCoeffRow(rows, coeffLevelCandidates);
    if (!best) continue;

    coeffBySubject.set(sid, {
      coeff: cleanCoeff(best.coeff),
      include: best.include_in_average !== false,
    });
  }

  /*
   * ✅ Règles spéciales par établissement et par matière.
   * Exemple : COURS SECONDAIRE CATHOLIQUE ABOISSO
   * LATIN / RELIGION doivent rester visibles au bulletin,
   * mais ne doivent pas compter dans la moyenne générale.
   *
   * Non cassant : si la table n'existe pas encore ou si aucune règle n'est trouvée,
   * l'ancien comportement institution_subject_coeffs reste inchangé.
   */
  const subjectGradePolicyBySubject = new Map<
    string,
    {
      includeInGeneralAverage: boolean | null;
      includeInConductAverage: boolean;
      conductWeight: number;
    }
  >();

  try {
    const { data: policyData, error: policyErr } = await srvClient
      .from("institution_subject_grade_policies")
      .select(
        "subject_id, include_in_general_average, include_in_conduct_average, conduct_weight, is_active"
      )
      .eq("institution_id", institutionId)
      .eq("is_active", true);

    if (!policyErr && policyData?.length) {
      for (const row of policyData as SubjectGradePolicyRow[]) {
        const sid = String(row.subject_id || "");
        if (!sid || !isUuid(sid)) continue;

        const includeInGeneralAverage =
          typeof row.include_in_general_average === "boolean"
            ? row.include_in_general_average
            : null;

        const conductWeightRaw = Number(row.conduct_weight ?? 1);
        const conductWeight =
          Number.isFinite(conductWeightRaw) && conductWeightRaw > 0 ? conductWeightRaw : 1;

        subjectGradePolicyBySubject.set(sid, {
          includeInGeneralAverage,
          includeInConductAverage: row.include_in_conduct_average === true,
          conductWeight,
        });

        // ✅ On surcharge uniquement l'inclusion dans la moyenne générale.
        // Le coefficient existant reste celui de institution_subject_coeffs s'il existe.
        if (includeInGeneralAverage !== null) {
          const existing = coeffBySubject.get(sid);
          coeffBySubject.set(sid, {
            coeff: existing ? existing.coeff : 1,
            include: includeInGeneralAverage,
          });
        }
      }
    }
  } catch (err) {
    console.warn("[bulletin] institution_subject_grade_policies indisponible", err);
  }

  const shouldIncludeSubjectInGeneralAverage = (
    subjectId: string,
    fallback: boolean
  ): boolean => {
    const policy = subjectGradePolicyBySubject.get(String(subjectId));
    if (policy && typeof policy.includeInGeneralAverage === "boolean") {
      return policy.includeInGeneralAverage;
    }
    return fallback;
  };

  /* 4) Evaluations publiées (peut être vide) */
  let evals: EvalRow[] = [];
  {
    let evalQuery = supabase
      .from("grade_evaluations")
      .select(
        "id, class_id, subject_id, teacher_id, eval_date, scale, coeff, is_published, subject_component_id"
      )
      .eq("class_id", classId)
      .eq("is_published", true);

    if (dateFrom) evalQuery = evalQuery.gte("eval_date", dateFrom);
    if (dateTo) evalQuery = evalQuery.lte("eval_date", dateTo);

    const { data: evalData, error: evalErr } = await evalQuery;

    if (evalErr) {
      return NextResponse.json({ ok: false, error: "EVALUATIONS_ERROR" }, { status: 500 });
    }

    evals = (evalData || []) as EvalRow[];
  }

  // sujets vus dans les évaluations publiées
  const subjectIdSet = new Set<string>();
  for (const e of evals) if (e.subject_id) subjectIdSet.add(String(e.subject_id));

  /*
   * ✅ Matières officiellement affectées à la classe
   * class_teachers.subject_id = institution_subjects.id ;
   * on le résout ensuite vers subjects.id.
   *
   * Règle métier :
   * - matière non affectée => invisible dans le bulletin ;
   * - matière affectée mais sans note publiée => avg20 = null, affichage NC / — côté front ;
   * - vraie note 0 publiée => avg20 = 0, conservée comme vraie moyenne.
   *
   * Fallback non cassant : si aucune affectation n'est trouvée pour la classe,
   * on conserve l'ancien comportement basé sur coeffs + évaluations.
   */
  const assignedSubjectIds = new Set<string>();

  {
    let ctQuery = srv
      .from("class_teachers")
      .select("subject_id, start_date, end_date")
      .eq("institution_id", institutionId)
      .eq("class_id", classId);

    const pivot = dateTo || dateFrom || null;
    if (pivot) {
      ctQuery = ctQuery
        .or(`end_date.is.null,end_date.gte.${pivot}`)
        .or(`start_date.is.null,start_date.lte.${pivot}`);
    } else {
      ctQuery = ctQuery.is("end_date", null);
    }

    const { data: ctData, error: ctErr } = await ctQuery;

    if (!ctErr && ctData?.length) {
      const instSubjectIds = Array.from(
        new Set(
          (ctData as any[])
            .map((row) => String(row.subject_id || ""))
            .filter((id) => !!id && isUuid(id))
        )
      );

      if (instSubjectIds.length) {
        const { data: instSubData, error: instSubErr } = await srv
          .from("institution_subjects")
          .select("id, subject_id")
          .eq("institution_id", institutionId)
          .in("id", instSubjectIds);

        if (!instSubErr && instSubData?.length) {
          (instSubData as any[]).forEach((row) => {
            const sid = String(row.subject_id || "");
            if (sid && isUuid(sid)) assignedSubjectIds.add(sid);
          });
        }
      }
    }
  }

  const hasAssignedSubjectsForClass = assignedSubjectIds.size > 0;

  // ✅ Lookup large : on charge les noms de toutes les matières possibles, puis on filtre après
  // avoir identifié les matières de conduite.
  const subjectIdsUnionRaw = Array.from(
    new Set([
      ...Array.from(subjectIdsFromConfig),
      ...Array.from(subjectIdSet),
      ...Array.from(assignedSubjectIds),
    ])
  );
  const subjectIds = subjectIdsUnionRaw.filter((sid) => isUuid(sid));

  // Si aucune matière trouvée (ni coeffs ni évals)
  if (!subjectIds.length) {
    const baseItems = classStudents.map((cs) => {
      const stu = cs.students || {};
      const fullName =
        stu.full_name || [stu.last_name, stu.first_name].filter(Boolean).join(" ") || "Élève";
      return {
        student_id: cs.student_id,
        full_name: fullName,
        matricule: stu.matricule || null,
        photo_url: stu.photo_url || null,
        gender: stu.gender || null,
        birth_date: stu.birthdate || null,
        birth_place: stu.birth_place || null,
        nationality: stu.nationality || null,
        regime: stu.regime || null,
        is_repeater: stu.is_repeater ?? null,
        is_boarder: stu.is_boarder ?? null,
        is_affecte: stu.is_affecte ?? null,
        per_subject: [],
        per_group: [],
        general_avg: null,
        rank: null as number | null,
        coverage: {
          expected_subjects: 0,
          covered_subjects: 0,
          missing_subjects: [],
          is_complete: false,
          has_academic_grade: false,
          status: "empty",
        },
        general_avg_is_complete: false,
        general_avg_status: "empty",
        per_subject_components: [],
        annual_avg: null as number | null,
        annual_rank: null as number | null,
        annual_coverage: null,
        annual_coverage_is_complete: false,
        annual_coverage_status: "not_last_period",
        annual_avg_is_complete: false,
        annual_avg_status: "not_last_period",
      };
    });

    applyPeriodNcOverridesToItems(baseItems, periodNcOverrideMap);

    const itemsWithQr = await addQrToItems(srvClient, baseItems, {
      origin,
      institutionId,
      classId: classRow.id,
      classAcademicYear: classRow.academic_year ?? null,
      periodMeta: {
        from: periodMeta.from ?? null,
        to: periodMeta.to ?? null,
        code: periodMeta.code ?? null,
        label: periodMeta.label ?? null,
        short_label: periodMeta.short_label ?? null,
        academic_year: periodMeta.academic_year ?? null,
      },
    });

    const itemsWithQrPng = await attachQrPng(itemsWithQr);

    return NextResponse.json({
      ok: true,
      qr: {
        enabled: qrEnabled,
        mode: qrMode,
        verify_path: BULLETIN_VERIFY_SHORT_PREFIX,
        legacy_verify_path: BULLETIN_VERIFY_LEGACY_PATH,
      },
      signatures: { enabled: bulletinSignaturesEnabled },
      class: {
        id: classRow.id,
        label: classRow.label || classRow.code || "Classe",
        code: classRow.code || null,
        academic_year: classRow.academic_year || null,
        level: classRow.level || null,
        official_track_code: classRow.official_track_code || null,
        coefficient_level: coeffLevelCandidates[0] || bulletinLevel || null,
        bulletin_level: bulletinLevel,
        head_teacher: headTeacher
          ? {
              id: headTeacher.id,
              display_name: headTeacher.display_name || null,
              phone: headTeacher.phone || null,
              email: headTeacher.email || null,
            }
          : null,
      },
      period: periodResponse,
      subjects: [],
      subject_groups: [],
      subject_components: [],
      items: itemsWithQrPng,
    });
  }

  /* 5) Noms/code matières (service client) */
  const { data: subjData, error: subjErr } = await srv
    .from("subjects")
    .select("id, name, code")
    .in("id", subjectIds)
    .order("name", { ascending: true });

  if (subjErr) {
    return NextResponse.json({ ok: false, error: "SUBJECTS_ERROR" }, { status: 500 });
  }

  const subjects = (subjData || []) as SubjectRow[];
  const subjectById = new Map<string, SubjectRow>();
  for (const s of subjects) subjectById.set(s.id, s);

  const isCSCADisciplineComponentSubjectId = (subjectId: string): boolean => {
    if (!isCSCA) return false;
    const meta = subjectById.get(String(subjectId));
    const key = normalizeAsciiToken(`${meta?.code ?? ""} ${meta?.name ?? ""}`);

    /*
     * CSCA : « Discipline » est le résultat des 4 rubriques de conduite
     * (assiduité, retards/sanctions, tenue, moralité/discipline).
     * Elle sert uniquement de composante interne pour calculer LA conduite finale
     * avec Religion et Latin. Elle ne doit donc pas ressortir comme une 2e
     * matière/ligne de bulletin.
     */
    return key.includes("discipline");
  };

  const isConductSubjectId = (subjectId: string): boolean => {
    const meta = subjectById.get(String(subjectId));
    const key = normalizeAsciiToken(`${meta?.code ?? ""} ${meta?.name ?? ""}`);
    return key.includes("conduite") || key.includes("conduct");
  };

  // ordre final des matières (par nom)
  // ✅ Si des affectations existent, on garde uniquement :
  // - les matières affectées à la classe ;
  // - les matières de conduite configurées ;
  // et on exclut les matières parasites simplement présentes dans le référentiel/coefficients.
  const orderedSubjectIds = subjects
    .map((s) => s.id)
    .filter((sid) => {
      if (!isUuid(sid)) return false;
      if (isCSCADisciplineComponentSubjectId(sid)) return false;
      if (!hasAssignedSubjectsForClass) return true;
      if (assignedSubjectIds.has(sid)) return true;
      if (isConductSubjectId(sid)) return true;
      return false;
    });

  /* 6) Liste matières pour le bulletin */
  const subjectsForReport = orderedSubjectIds.map((sid) => {
    const s = subjectById.get(sid);
    const name = s?.name || s?.code || "Matière";
    const info = coeffBySubject.get(sid);
    const coeffBulletin = info ? info.coeff : 1;

    // CSCA : Latin et Religion restent visibles sur le bulletin,
    // mais ils ne participent PAS à la moyenne trimestrielle générale.
    // Ils servent uniquement de composantes au calcul spécial de la conduite.
    const isCSCAConductComponentOnly = isCSCA && isCSCALatinOrReligionSubjectMeta(s);

    const includeInAverage = isCSCAConductComponentOnly
      ? false
      : shouldIncludeSubjectInGeneralAverage(
          sid,
          info ? info.include : true
        );

    return {
      subject_id: sid,
      subject_name: name,
      coeff_bulletin: coeffBulletin,
      include_in_average: includeInAverage,

      // Métadonnée front non cassante : permet d'afficher Latin/Religion
      // avec une forme visuelle spéciale au CSCA, sans ajouter de texte sur le bulletin.
      is_conduct_component_only: isCSCAConductComponentOnly,
    };
  });

  // ✅ La conduite peut compléter la moyenne, mais ne doit jamais suffire à elle seule.
  // On la garde "include_in_average = true" pour les cas où il existe déjà au moins
  // une vraie note disciplinaire publiée sur la période.
  for (const s of subjectsForReport as any[]) {
    const meta = subjectById.get(String(s.subject_id));
    const key = normalizeAsciiToken(`${meta?.code ?? ""} ${meta?.name ?? ""}`);
    if (key.includes("conduite") || key.includes("conduct")) {
      s.include_in_average = true;
      const c = Number(s.coeff_bulletin ?? 0);
      if (!c || c <= 0) s.coeff_bulletin = 1;
    }
  }

  /* 6bis) Sous-matières
   *
   * ✅ Règle métier importante :
   * Les sous-matières ne sont affichées/calculées comme lignes séparées que
   * pour les niveaux collège (6e, 5e, 4e, 3e).
   *
   * Pour le lycée (seconde, première, terminale), même si des composants
   * existent encore dans le référentiel ou dans d’anciennes évaluations,
   * ils ne doivent PAS apparaître sur le bulletin. La matière principale
   * reste unique.
   */
  let subjectComponentsForReport: BulletinSubjectComponent[] = [];
  const subjectComponentById = new Map<string, BulletinSubjectComponent>();
  const compsBySubject = new Map<string, BulletinSubjectComponent[]>();

  if (allowSubjectComponents && orderedSubjectIds.length) {
    const { data: compData, error: compErr } = await srv
      .from("grade_subject_components")
      .select("id, subject_id, label, short_label, coeff_in_subject, order_index, is_active, level")
      .eq("institution_id", institutionId)
      .in("subject_id", orderedSubjectIds);

    if (compErr) {
      // ignore
    } else {
      const rawRows = ((compData || []) as any[])
        .filter((r) => r.is_active !== false)
        .map((r: any) => ({
          id: String(r.id),
          subject_id: String(r.subject_id),
          label: (r.label as string) || "Sous-matière",
          short_label: r.short_label ? String(r.short_label) : null,
          coeff_in_subject: cleanCoeff(
            r.coeff_in_subject !== null && r.coeff_in_subject !== undefined
              ? Number(r.coeff_in_subject)
              : 1
          ),
          order_index:
            r.order_index !== null && r.order_index !== undefined ? Number(r.order_index) : 1,
          level: r.level ? String(r.level) : null,
        }));

      const rawBySubject = new Map<string, any[]>();
      for (const row of rawRows) {
        const arr = rawBySubject.get(row.subject_id) || [];
        arr.push(row);
        rawBySubject.set(row.subject_id, arr);
      }

      const finalRows: BulletinSubjectComponent[] = [];

      for (const sid of orderedSubjectIds) {
        const chosen = pickBestComponentRows(rawBySubject.get(sid) || [], coeffLevelCandidates);

        chosen.sort((a, b) => {
          return (a.order_index ?? 1) - (b.order_index ?? 1);
        });

        for (const row of chosen) {
          finalRows.push({
            id: row.id,
            subject_id: row.subject_id,
            label: row.label,
            short_label: row.short_label,
            coeff_in_subject: row.coeff_in_subject,
            order_index: row.order_index,
          });
        }
      }

      subjectComponentsForReport = finalRows;

      finalRows.forEach((c) => {
        subjectComponentById.set(c.id, c);
        const arr = compsBySubject.get(c.subject_id) || [];
        arr.push(c);
        compsBySubject.set(c.subject_id, arr);
      });
    }
  }

  /* 6ter) Groupes (BILAN LETTRES / SCIENCES / AUTRES) */
  let subjectGroups: BulletinSubjectGroup[] = [];
  let groupedSubjectIds = new Set<string>();

  const subjectInfoById = new Map<string, { name: string; code: string }>();
  subjects.forEach((s) =>
    subjectInfoById.set(s.id, { name: s.name ?? "", code: s.code ?? "" })
  );

  // ⚙️ (A) essayer d'abord la config DB avec la série officielle en priorité
  if (coeffLevelCandidates.length) {
    const { data: groupsData, error: groupsErr } = await srv
      .from("bulletin_subject_groups")
      .select("id, level, label, order_index, is_active, code, short_label, annual_coeff")
      .eq("institution_id", institutionId)
      .order("order_index", { ascending: true });

    if (groupsErr) {
      // ignore
    } else if (groupsData && groupsData.length) {
      const activeAllGroups = (groupsData as any[]).filter((g) => g.is_active !== false);
      let activeGroups: any[] = [];

      for (const wantedLevel of coeffLevelCandidates) {
        const wanted = normalizeStoredLevel(wantedLevel);
        const matching = activeAllGroups.filter((g) => normalizeStoredLevel(g.level) === wanted);
        if (matching.length) {
          activeGroups = matching;
          break;
        }
      }

      if (activeGroups.length) {
        const groupIds = activeGroups.map((g) => String(g.id));

        const { data: itemsData, error: itemsErr } = await srv
          .from("bulletin_subject_group_items")
          .select("id, group_id, subject_id, created_at")
          .in("group_id", groupIds);

        if (itemsErr) {
          // ignore
        }

        const rawItems = (itemsData || []) as any[];

        rawItems.sort((a, b) => {
          const ag = String(a.group_id || "");
          const bg = String(b.group_id || "");
          if (ag !== bg) return ag.localeCompare(bg);
          const ac = String(a.created_at || "");
          const bc = String(b.created_at || "");
          return ac.localeCompare(bc);
        });

        const itemsByGroup = new Map<string, any[]>();
        rawItems.forEach((row) => {
          const gId = String(row.group_id);
          const arr = itemsByGroup.get(gId) || [];
          arr.push(row);
          itemsByGroup.set(gId, arr);
        });

        const builtGroups: BulletinSubjectGroup[] = activeGroups.map((g: any) => {
          const rows = itemsByGroup.get(String(g.id)) || [];
          const items: BulletinSubjectGroupItem[] = rows.flatMap((row: any, idx: number) => {
            const sid = row.subject_id ? String(row.subject_id) : "";
            if (!sid || !isUuid(sid)) return [];
            if (!orderedSubjectIds.includes(sid)) return []; // éviter matières hors bulletin

            const meta = subjectInfoById.get(sid) || { name: "", code: "" };
            const subjectName = meta.name || meta.code || "Matière";

            return [
              {
                id: String(row.id),
                group_id: String(row.group_id),
                subject_id: sid,
                subject_name: String(subjectName),
                order_index: idx + 1,
                subject_coeff_override: null,
                is_optional: false,
              },
            ];
          });

          const groupCode =
            g.code && String(g.code).trim() !== "" ? String(g.code) : String(g.label);

          const shortLabel =
            g.short_label && String(g.short_label).trim() !== "" ? String(g.short_label) : null;

          const builtGroup: BulletinSubjectGroup = {
            id: String(g.id),
            code: groupCode,
            label: String(g.label),
            short_label: shortLabel,
            order_index: Number(g.order_index ?? 1),
            is_active: g.is_active !== false,
            annual_coeff: 0,
            items,
          };

          return {
            ...builtGroup,
            annual_coeff: computeGroupAnnualCoeff(builtGroup, coeffBySubject),
          };
        });

        // ROUTAGE + ANTI-DOUBLONS + EPS=>AUTRES + PHILO=>LETTRES
        const gLetters = findGroupByMeaning(builtGroups, "LETTRES");
        const gSciences = findGroupByMeaning(builtGroups, "SCIENCES");
        const gAutres = findGroupByMeaning(builtGroups, "AUTRES");

        const chosenGroupIdBySubject = new Map<string, string>();
        const firstSeenOrder = new Map<string, number>();

        const groupOrder = builtGroups
          .slice()
          .sort((a, b) => a.order_index - b.order_index)
          .map((g) => g.id);

        const groupById = new Map<string, BulletinSubjectGroup>();
        builtGroups.forEach((g) => groupById.set(g.id, g));

        function desiredGroupIdForSubject(sid: string): string | null {
          const meta = subjectInfoById.get(sid) || { name: "", code: "" };
          const name = meta.name;
          const code = meta.code;

          // ✅ Règle blindée : AUTRES = complément de (LETTRES ∪ SCIENCES)
          if (isScienceSubject(name, code) && gSciences?.id) return gSciences.id;
          if (isLettersSubject(name, code) && gLetters?.id) return gLetters.id;

          // par défaut, tout le reste en AUTRES
          if (gAutres?.id) return gAutres.id;

          // fallback ultime (si un groupe manque en DB)
          return gLetters?.id ?? gSciences?.id ?? null;
        }

        // first seen
        for (const gid of groupOrder) {
          const g = groupById.get(gid);
          if (!g) continue;
          for (const it of g.items) {
            const sid = it.subject_id;
            if (!isUuid(sid)) continue;
            if (!firstSeenOrder.has(sid)) firstSeenOrder.set(sid, it.order_index);
            if (!chosenGroupIdBySubject.has(sid)) chosenGroupIdBySubject.set(sid, g.id);
          }
        }

        // forçages
        for (const sid of chosenGroupIdBySubject.keys()) {
          const desired = desiredGroupIdForSubject(sid);
          if (desired) chosenGroupIdBySubject.set(sid, desired);
        }

        // reconstruire
        const rebuilt = builtGroups.map((g) => ({ ...g, items: [] as BulletinSubjectGroupItem[] }));
        const rebuiltById = new Map<string, BulletinSubjectGroup>();
        rebuilt.forEach((g) => rebuiltById.set(g.id, g));

        for (const [sid, gid] of chosenGroupIdBySubject.entries()) {
          const target = rebuiltById.get(gid);
          if (!target) continue;

          const meta = subjectInfoById.get(sid) || { name: "", code: "" };
          const subjectName = meta.name || meta.code || "Matière";

          target.items.push({
            id: `virt-${sid}`,
            group_id: gid,
            subject_id: sid,
            subject_name: subjectName,
            order_index: firstSeenOrder.get(sid) ?? 9999,
            subject_coeff_override: null,
            is_optional: false,
          });
        }

        rebuilt.forEach((g) => {
          g.items.sort((a, b) => a.order_index - b.order_index);
          g.items = g.items.map((it, idx) => ({ ...it, order_index: idx + 1 }));
          g.annual_coeff = computeGroupAnnualCoeff(g, coeffBySubject);
        });

        subjectGroups = rebuilt;

        groupedSubjectIds = new Set<string>();
        subjectGroups.forEach((g) => {
          g.items.forEach((it) => {
            if (orderedSubjectIds.includes(it.subject_id)) groupedSubjectIds.add(it.subject_id);
          });
        });
      }
    }
  }

  // ⚙️ (B) fallback auto : si aucune config DB exploitable => on fabrique bilans LETTRES/SCIENCES/AUTRES
  if (!subjectGroups.length) {
    subjectGroups = buildFallbackGroups({
      subjectIds: orderedSubjectIds,
      subjectInfoById,
      coeffBySubject,
    });

    groupedSubjectIds = new Set<string>();
    subjectGroups.forEach((g) => g.items.forEach((it) => groupedSubjectIds.add(it.subject_id)));
  }

  const hasGroupConfig = subjectGroups.length > 0;

  /* 7) Notes officielles publiées (si evals présentes) */
  const evalById = new Map<string, EvalRow>();
  for (const e of evals) evalById.set(e.id, e);

  /**
   * ✅ Source officielle robuste pour les bulletins.
   *
   * Important : une classe complète peut dépasser la limite implicite Supabase/PostgREST
   * d'une requête standard. Exemple CSCA 5e2 T3 : 49 évaluations × 29 élèves = 1414
   * notes officielles. Sans pagination, seules les premières lignes reviennent et les
   * derniers élèves peuvent apparaître NC alors que leurs notes publiées existent bien.
   *
   * Règle : on lit TOUTES les lignes publiées par pages, d'abord dans
   * grade_published_scores.is_current = true, puis on complète avec la vue pour garder
   * la compatibilité avec l'existant.
   */
  async function loadOfficialScoreRowsForEvalIds(evalIds: string[]): Promise<ScoreRow[]> {
    if (!evalIds.length || !studentIds.length) return [];

    const PAGE_SIZE = 1000;

    const byKey = new Map<string, ScoreRow>();
    const ingest = (rows: any[] | null | undefined, prefer: boolean) => {
      for (const row of rows || []) {
        const evaluationId = String(row?.evaluation_id || "");
        const studentId = String(row?.student_id || "");
        if (!evaluationId || !studentId) continue;

        const key = `${evaluationId}__${studentId}`;
        if (!prefer && byKey.has(key)) continue;

        byKey.set(key, {
          evaluation_id: evaluationId,
          student_id: studentId,
          score: row?.score === null || row?.score === undefined ? null : Number(row.score),
        });
      }
    };

    async function fetchDirectPublishedScores(): Promise<{ rows: any[]; error: any | null }> {
      const rows: any[] = [];

      for (let from = 0; ; from += PAGE_SIZE) {
        const to = from + PAGE_SIZE - 1;

        const { data, error } = await srvClient
          .from("grade_published_scores")
          .select("evaluation_id, student_id, score")
          .eq("institution_id", institutionId)
          .eq("class_id", classId)
          .eq("is_current", true)
          .in("evaluation_id", evalIds)
          .in("student_id", studentIds)
          .order("evaluation_id", { ascending: true })
          .order("student_id", { ascending: true })
          .range(from, to);

        if (error) return { rows, error };

        const chunk = (data || []) as any[];
        rows.push(...chunk);

        if (chunk.length < PAGE_SIZE) break;
      }

      return { rows, error: null };
    }

    async function fetchViewOfficialScores(): Promise<{ rows: any[]; error: any | null }> {
      const rows: any[] = [];

      for (let from = 0; ; from += PAGE_SIZE) {
        const to = from + PAGE_SIZE - 1;

        const { data, error } = await supabase
          .from("v_grade_scores_official_for_reports")
          .select("evaluation_id, student_id, score")
          .in("evaluation_id", evalIds)
          .in("student_id", studentIds)
          .order("evaluation_id", { ascending: true })
          .order("student_id", { ascending: true })
          .range(from, to);

        if (error) return { rows, error };

        const chunk = (data || []) as any[];
        rows.push(...chunk);

        if (chunk.length < PAGE_SIZE) break;
      }

      return { rows, error: null };
    }

    const direct = await fetchDirectPublishedScores();
    if (!direct.error) ingest(direct.rows, true);

    const fromView = await fetchViewOfficialScores();
    if (!fromView.error) ingest(fromView.rows, false);

    if (!byKey.size && direct.error && fromView.error) {
      throw fromView.error || direct.error;
    }

    if (direct.error) {
      console.warn("[bulletin] lecture directe grade_published_scores indisponible", direct.error);
    }
    if (fromView.error) {
      console.warn(
        "[bulletin] vue v_grade_scores_official_for_reports indisponible",
        fromView.error
      );
    }

    const expectedMax = evalIds.length * studentIds.length;
    if (byKey.size < expectedMax) {
      console.warn("[bulletin] scores officiels incomplets apres pagination", {
        received: byKey.size,
        expectedMax,
        evals: evalIds.length,
        students: studentIds.length,
      });
    }

    return Array.from(byKey.values());
  }

  let scores: ScoreRow[] = [];
  if (evals.length) {
    const evalIds = evals.map((e) => e.id);

    try {
      scores = await loadOfficialScoreRowsForEvalIds(evalIds);
    } catch (scoreErr) {
      console.warn("[bulletin] scores officiels indisponibles", scoreErr);
      return NextResponse.json({ ok: false, error: "SCORES_ERROR" }, { status: 500 });
    }
  }

  /* 7bis) Bonus pédagogiques officiels pour le bulletin
   *
   * Règle métier Mon Cahier :
   * - la publication verrouille les notes brutes ;
   * - elle ne verrouille pas les bonus pédagogiques ;
   * - les bulletins, rangs et QR doivent utiliser les moyennes finales bonus inclus.
   *
   * Compatibilité : on accepte les anciennes lignes sans grading_period_id
   * et les nouvelles lignes rattachées à une période. Si les deux existent,
   * la ligne de la période courante est prioritaire.
   */
  async function loadAdjustmentBonusMaps(params: {
    academicYear: string | null | undefined;
    periodId?: string | null;
  }): Promise<AdjustmentBonusMaps> {
    const empty: AdjustmentBonusMaps = {
      subjectBonusByStudent: new Map(),
      generalBonusByStudent: new Map(),
    };

    const academicYear = String(params.academicYear || "").trim();
    if (!academicYear || !studentIds.length) return empty;

    const selectedByKey = new Map<
      string,
      { student_id: string; subject_id: string | null; bonus: number; priority: number }
    >();

    const ingest = (rows: GradeAdjustmentBonusRow[], hasPeriodColumn: boolean) => {
      for (const row of rows || []) {
        const sid = String(row.student_id || "").trim();
        if (!sid) continue;

        const rawBonus = Number(row.bonus ?? 0);
        if (!Number.isFinite(rawBonus)) continue;

        const subjectId = row.subject_id ? String(row.subject_id) : null;
        const rowPeriodId = hasPeriodColumn
          ? row.grading_period_id
            ? String(row.grading_period_id)
            : null
          : null;

        // Si une période est connue :
        // - on garde les bonus de cette période ;
        // - on garde aussi les anciens bonus sans période ;
        // - on ignore les bonus d'une autre période.
        let priority = 1;
        if (params.periodId) {
          if (rowPeriodId === params.periodId) priority = 2;
          else if (!rowPeriodId) priority = 1;
          else continue;
        }

        const key = `${sid}__${subjectId ?? "__GENERAL__"}`;
        const existing = selectedByKey.get(key);
        if (!existing || priority >= existing.priority) {
          selectedByKey.set(key, {
            student_id: sid,
            subject_id: subjectId,
            bonus: Number(rawBonus.toFixed(2)),
            priority,
          });
        }
      }
    };

    try {
      // Requête moderne : tient compte de grading_period_id quand la colonne existe.
      const { data, error } = await srvClient
        .from("grade_adjustments")
        .select("student_id, subject_id, grading_period_id, bonus")
        .eq("class_id", classRow.id)
        .eq("academic_year", academicYear)
        .in("student_id", studentIds);

      if (error) throw error;
      ingest((data || []) as GradeAdjustmentBonusRow[], true);
    } catch (error: any) {
      // Non cassant : si la migration grading_period_id n'est pas encore disponible,
      // on retombe sur l'ancien format de table.
      try {
        const { data, error: fallbackError } = await srvClient
          .from("grade_adjustments")
          .select("student_id, subject_id, bonus")
          .eq("class_id", classRow.id)
          .eq("academic_year", academicYear)
          .in("student_id", studentIds);

        if (fallbackError) throw fallbackError;
        ingest((data || []) as GradeAdjustmentBonusRow[], false);
      } catch (fallbackError) {
        console.warn("[bulletin] bonus indisponibles pour le bulletin", {
          academicYear,
          periodId: params.periodId ?? null,
          error: fallbackError,
        });
      }
    }

    const out: AdjustmentBonusMaps = {
      subjectBonusByStudent: new Map(),
      generalBonusByStudent: new Map(),
    };

    for (const row of selectedByKey.values()) {
      if (row.subject_id) {
        let bySubject = out.subjectBonusByStudent.get(row.student_id);
        if (!bySubject) {
          bySubject = new Map();
          out.subjectBonusByStudent.set(row.student_id, bySubject);
        }
        bySubject.set(row.subject_id, row.bonus);
      } else {
        out.generalBonusByStudent.set(row.student_id, row.bonus);
      }
    }

    return out;
  }

  const currentBonusMaps = await loadAdjustmentBonusMaps({
    academicYear: bulletinAcademicYear,
    periodId: periodMeta.id ?? null,
  });

  /* 8) Maps calcul */
  const perStudentSubject = new Map<string, Map<string, { sumWeighted: number; sumCoeff: number }>>();

  const perStudentSubjectComponent = new Map<
    string,
    Map<string, { subject_id: string; sumWeighted: number; sumCoeff: number }>
  >();

  for (const sc of scores) {
    const ev = evalById.get(sc.evaluation_id);
    if (!ev) continue;
    if (!ev.subject_id) continue;
    if (!ev.scale || ev.scale <= 0) continue;
    if (sc.score === null || sc.score === undefined) continue;

    const score = Number(sc.score);
    if (!Number.isFinite(score)) continue;

    const norm20 = (score / ev.scale) * 20;
    const weight = ev.coeff ?? 1;

    let stuMap = perStudentSubject.get(sc.student_id);
    if (!stuMap) {
      stuMap = new Map();
      perStudentSubject.set(sc.student_id, stuMap);
    }
    const key = ev.subject_id;
    const cell = stuMap.get(key) || { sumWeighted: 0, sumCoeff: 0 };
    cell.sumWeighted += norm20 * weight;
    cell.sumCoeff += weight;
    stuMap.set(key, cell);

    if (ev.subject_component_id) {
      const comp = subjectComponentById.get(ev.subject_component_id);
      if (comp) {
        let stuCompMap = perStudentSubjectComponent.get(sc.student_id);
        if (!stuCompMap) {
          stuCompMap = new Map();
          perStudentSubjectComponent.set(sc.student_id, stuCompMap);
        }
        const compCell =
          stuCompMap.get(comp.id) || { subject_id: comp.subject_id, sumWeighted: 0, sumCoeff: 0 };
        compCell.sumWeighted += norm20 * weight;
        compCell.sumCoeff += weight;
        stuCompMap.set(comp.id, compCell);
      }
    }
  }

  /* 9) Construire la réponse (par élève) */

  // ✅ Conduite (coef 1) : on la récupère une seule fois pour la période demandée
  const conductAvgByStudent =
    dateFrom && dateTo ? await fetchConductAverageMap(String(dateFrom), String(dateTo)) : null;

  const items = classStudents.map((cs) => {
    const stu = cs.students || {};
    const fullName =
      stu.full_name || [stu.last_name, stu.first_name].filter(Boolean).join(" ") || "Élève";

    const stuMap =
      perStudentSubject.get(cs.student_id) ||
      new Map<string, { sumWeighted: number; sumCoeff: number }>();

    const stuCompMap =
      perStudentSubjectComponent.get(cs.student_id) ||
      new Map<string, { subject_id: string; sumWeighted: number; sumCoeff: number }>();

    // sous-matières
    const per_subject_components =
      subjectComponentsForReport.length === 0
        ? []
        : subjectComponentsForReport.map((comp) => {
            const cell = stuCompMap.get(comp.id);
            let avg20: number | null = null;
            if (cell && cell.sumCoeff > 0) {
              avg20 = cleanNumber(cell.sumWeighted / cell.sumCoeff, 4);
            }
            return {
              subject_id: comp.subject_id,
              component_id: comp.id,
              avg20,
            };
          });

    // matière: ✅ si elle a des composants, on recalcule avg depuis les sous-matières
    const per_subject = subjectsForReport.map((s) => {
      const comps = compsBySubject.get(s.subject_id) || [];

      let avg20: number | null = null;

      // ✅ priorité: calcul depuis sous-matières si au moins 1 sous-matière notée
      if (comps.length) {
        let sum = 0;
        let sumW = 0;

        for (const comp of comps) {
          const cell = stuCompMap.get(comp.id);
          if (!cell || cell.sumCoeff <= 0) continue;

          const compAvgRaw = cell.sumWeighted / cell.sumCoeff;
          if (!Number.isFinite(compAvgRaw)) continue;

          const w = comp.coeff_in_subject ?? 1;
          if (!w || w <= 0) continue;

          sum += compAvgRaw * w;
          sumW += w;
        }

        if (sumW > 0) {
          avg20 = cleanNumber(sum / sumW, 4);
        }
      }

      // fallback: calcul direct via évaluations de la matière
      if (avg20 === null) {
        const cell = stuMap.get(s.subject_id);
        if (cell && cell.sumCoeff > 0) {
          avg20 = cleanNumber(cell.sumWeighted / cell.sumCoeff, 4);
        }
      }

      const rawAvg20 = avg20;
      const subjectBonus =
        currentBonusMaps.subjectBonusByStudent
          .get(cs.student_id)
          ?.get(String(s.subject_id)) ?? 0;

      if (avg20 !== null && avg20 !== undefined && Number.isFinite(Number(avg20))) {
        const adjusted = clampAverage20(Number(avg20) + subjectBonus);
        avg20 = adjusted === null ? null : cleanNumber(adjusted, 4);
      }

      const hasGrade = avg20 !== null && avg20 !== undefined && Number.isFinite(Number(avg20));

      return {
        subject_id: s.subject_id,
        avg20,

        // ✅ Bonus matière appliqué au bulletin sans casser l'ancien front.
        // avg20 = moyenne finale matière ; avg20_before_bonus garde la trace brute.
        bonus: Number(subjectBonus.toFixed(2)),
        avg20_before_bonus: rawAvg20,

        // ✅ Métadonnées NC : ne cassent pas le front existant, mais permettent
        // aux bulletins/matrices d'afficher clairement NC / — sans confondre avec 0.
        has_grade: hasGrade,
        is_nc: !hasGrade,
        is_assigned:
          !hasAssignedSubjectsForClass ||
          assignedSubjectIds.has(String(s.subject_id)) ||
          isConductSubjectId(String(s.subject_id)),

        // ✅ champs ajoutés (remplis plus bas par attachTeachersToSubjects + signatures)
        teacher_id: null as string | null,
        teacher_name: null as string | null,
        teacher_signature_png: null as string | null,
      };
    });

    // moyennes par bilan (pondérées par coeff bulletin des matières)
    let per_group:
      | {
          group_id: string;
          group_avg: number | null;
        }[] = [];

    if (hasGroupConfig) {
      const coeffBulletinBySubject = new Map<string, number>();
      subjectsForReport.forEach((s) =>
        coeffBulletinBySubject.set(s.subject_id, Number(s.coeff_bulletin ?? 1))
      );

      per_group = subjectGroups.map((g) => {
        let sum = 0;
        let sumCoeffLocal = 0;

        for (const it of g.items) {
          const sid = it.subject_id;

          const ps = (per_subject as any[]).find((x) => x.subject_id === sid);
          const subAvg = ps?.avg20 ?? null;
          if (subAvg === null || subAvg === undefined) continue;

          const officialCoeff = Number(coeffBulletinBySubject.get(sid) ?? 0);
          const overrideCoeff = Number(it.subject_coeff_override ?? NaN);
          const w =
            Number.isFinite(officialCoeff) && officialCoeff > 0
              ? officialCoeff
              : Number.isFinite(overrideCoeff) && overrideCoeff > 0
                ? overrideCoeff
                : 1;

          if (!w || w <= 0) continue;

          sum += Number(subAvg) * w;
          sumCoeffLocal += w;
        }

        const groupAvg = sumCoeffLocal > 0 ? cleanNumber(sum / sumCoeffLocal, 4) : null;

        return {
          group_id: g.id,
          group_avg: groupAvg,
        };
      });
    }

    // ✅ moyenne générale: la conduite peut compléter, mais ne valide jamais seule un trimestre
    let general_avg: number | null = null;
    let hasAcademicContributionForGeneral = false;
    {
      let academicSumGen = 0;
      let academicSumCoeffGen = 0;
      let conductSumGen = 0;
      let conductSumCoeffGen = 0;
      let conductAlreadyCounted = false;
      let hasAcademicContribution = false;

      for (const s of subjectsForReport) {
        if (s.include_in_average === false) continue;
        const coeffSub = Number(s.coeff_bulletin ?? 0);
        if (!coeffSub || coeffSub <= 0) continue;

        const ps = (per_subject as any[]).find((x) => x.subject_id === s.subject_id);
        const subAvg = ps?.avg20 ?? null;
        if (subAvg === null || subAvg === undefined) continue;

        const isConduct = isConductSubjectId(String(s.subject_id));

        if (isConduct) {
          conductAlreadyCounted = true;
          conductSumGen += Number(subAvg) * coeffSub;
          conductSumCoeffGen += coeffSub;
          continue;
        }

        hasAcademicContribution = true;
        hasAcademicContributionForGeneral = true;
        academicSumGen += Number(subAvg) * coeffSub;
        academicSumCoeffGen += coeffSub;
      }

      // ✅ Pas de vraie note disciplinaire publiée => pas de moyenne trimestrielle
      if (hasAcademicContribution) {
        // ✅ La conduite externe (/conduite/averages) ne complète qu'un trimestre déjà valide
        if (!conductAlreadyCounted && conductAvgByStudent) {
          const c = conductAvgByStudent.get(cs.student_id);
          if (c !== null && c !== undefined && Number.isFinite(Number(c))) {
            conductSumGen += Number(c) * 1;
            conductSumCoeffGen += 1;
          }
        }

        const sumGen = academicSumGen + conductSumGen;
        const sumCoeffGen = academicSumCoeffGen + conductSumCoeffGen;
        general_avg = sumCoeffGen > 0 ? cleanNumber(sumGen / sumCoeffGen, 4) : null;
      } else {
        general_avg = null;
      }
    }

    const generalAvgBeforeBonus = general_avg;
    const generalBonus = currentBonusMaps.generalBonusByStudent.get(cs.student_id) ?? 0;

    if (general_avg !== null && general_avg !== undefined && Number.isFinite(Number(general_avg))) {
      const adjustedGeneral = clampAverage20(Number(general_avg) + generalBonus);
      general_avg = adjustedGeneral === null ? null : cleanNumber(adjustedGeneral, 4);
    }

    const expectedAverageSubjects = subjectsForReport.filter((s) => {
      if (s.include_in_average === false) return false;
      const coeffSub = Number(s.coeff_bulletin ?? 0);
      if (!coeffSub || coeffSub <= 0) return false;
      if (isConductSubjectId(String(s.subject_id))) return false;
      return true;
    });

    const coveredAverageSubjectIds = new Set<string>();
    for (const ps of per_subject as any[]) {
      if (isConductSubjectId(String(ps.subject_id))) continue;
      if (typeof ps.avg20 === "number" && Number.isFinite(ps.avg20)) {
        coveredAverageSubjectIds.add(String(ps.subject_id));
      }
    }

    const missingAverageSubjects = expectedAverageSubjects
      .filter((s) => !coveredAverageSubjectIds.has(String(s.subject_id)))
      .map((s) => ({
        subject_id: s.subject_id,
        subject_name: s.subject_name,
      }));

    const coverage = {
      expected_subjects: expectedAverageSubjects.length,
      covered_subjects: coveredAverageSubjectIds.size,
      missing_subjects: missingAverageSubjects,
      is_complete:
        expectedAverageSubjects.length > 0 &&
        coveredAverageSubjectIds.size === expectedAverageSubjects.length,
      has_academic_grade: hasAcademicContributionForGeneral,
      status:
        expectedAverageSubjects.length === 0
          ? "empty"
          : coveredAverageSubjectIds.size === expectedAverageSubjects.length
            ? "complete"
            : coveredAverageSubjectIds.size > 0
              ? "partial"
              : "empty",
    };

    return {
      student_id: cs.student_id,
      full_name: fullName,
      matricule: stu.matricule || null,

      // ✅ photo (ajouté sans retirer quoi que ce soit)
      photo_url: stu.photo_url || null,

      gender: stu.gender || null,
      birth_date: stu.birthdate || null,
      birth_place: stu.birth_place || null,
      nationality: stu.nationality || null,
      regime: stu.regime || null,
      is_repeater: stu.is_repeater ?? null,
      is_boarder: stu.is_boarder ?? null,
      is_affecte: stu.is_affecte ?? null,
      per_subject,
      per_group,
      general_avg,
      general_bonus: Number(generalBonus.toFixed(2)),
      general_avg_before_bonus: generalAvgBeforeBonus,
      rank: null as number | null,

      // ✅ Couverture pédagogique : on conserve les matières manquantes pour informer l’admin.
      // ✅ Nouvelle règle : une moyenne générale calculable reste classable, même si la couverture est partielle.
      coverage,
      coverage_is_complete: coverage.is_complete,
      coverage_status: coverage.status,
      general_avg_is_complete: general_avg !== null,
      general_avg_status: general_avg !== null ? "complete" : "empty",

      per_subject_components,

      // ✅ annuel (rempli seulement si is_last)
      annual_avg: null as number | null,
      annual_rank: null as number | null,
    };
  });

  applyPeriodNcOverridesToItems(items, periodNcOverrideMap);

  // ✅ Rang général trimestriel
  // Nouvelle règle : on classe tout élève qui possède une moyenne générale calculable.
  // Une couverture partielle n'annule plus automatiquement le rang.
  // L’admin pourra ensuite forcer NC au général depuis l’interface bulletin.
  const generalAvgByStudent = new Map<string, number | null>();
  for (const it of items as any[]) {
    const g = cleanNumber(it?.general_avg, 4);
    generalAvgByStudent.set(String(it.student_id), g);
  }

  const generalRankByStudent = buildRankMapFromAverageMap(generalAvgByStudent);
  for (const it of items as any[]) {
    const g = generalAvgByStudent.get(String(it.student_id)) ?? null;
    (it as any).rank = g !== null ? generalRankByStudent.get(String(it.student_id)) ?? null : null;
  }

  // Rang matière / sous-matière
  applySubjectRanks(items);
  applySubjectComponentRanks(items);

  // ✅ Professeurs par matière (même si evals vides : fallback class_teachers)
  await attachTeachersToSubjects(
    supabase,
    srv,
    items,
    evals,
    orderedSubjectIds,
    institutionId,
    classRow.id,
    dateFrom,
    dateTo
  );

  // ✅ Signatures (uniquement si option établissement activée)
  if (bulletinSignaturesEnabled) {
    const teacherIds: string[] = [];
    for (const it of items) {
      const ps = it.per_subject as any[] | undefined;
      if (!Array.isArray(ps)) continue;
      for (const cell of ps) {
        const tid = cell?.teacher_id ? String(cell.teacher_id) : "";
        if (tid && isUuid(tid)) teacherIds.push(tid);
      }
    }

    const sigMap = await getTeacherSignaturesAsDataUrl(srvClient, institutionId, teacherIds);

    for (const it of items) {
      const ps = it.per_subject as any[] | undefined;
      if (!Array.isArray(ps)) continue;

      for (const cell of ps) {
        const tid = cell?.teacher_id ? String(cell.teacher_id) : "";
        (cell as any).teacher_signature_png = tid ? sigMap.get(tid) ?? null : null;
      }
    }
  }

  /* ✅ 10) ANNUEL : calculer uniquement si périodes définies ET bulletin = dernière période */
  if (periodsDefined && isLastPeriod && periodsForYear.length) {
    // ✅ Pour l'annuel, il faut considérer les moyennes de CHAQUE trimestre (ou période),
    // en incluant toutes les matières réellement évaluées sur l'année.
    // Sinon, si le dernier trimestre ne contient que quelques matières, l'annuel est faussé.
    const yearFrom = String(periodsForYear[0]?.start_date ?? dateFrom ?? "");
    const yearTo = String(lastPeriod?.end_date ?? dateTo ?? "");

    // 1) Matières vues sur toute l'année (évaluations publiées)
    const annualSubjectIds = new Set<string>(orderedSubjectIds);
    if (yearFrom && yearTo) {
      const { data: yEvals, error: yErr } = await supabase
        .from("grade_evaluations")
        .select("subject_id")
        .eq("class_id", classId)
        .eq("is_published", true)
        .gte("eval_date", yearFrom)
        .lte("eval_date", yearTo);

      if (!yErr && yEvals?.length) {
        for (const r of yEvals as any[]) {
          const sid = r?.subject_id ? String(r.subject_id) : "";
          if (!sid || !isUuid(sid)) continue;
          if (!hasAssignedSubjectsForClass || assignedSubjectIds.has(sid) || isConductSubjectId(sid)) {
            annualSubjectIds.add(sid);
          }
        }
      }
    }

    // 2) Charger le nom/code pour les matières manquantes
    const annualOrderedSubjectIds = Array.from(annualSubjectIds).filter(
      (sid) => isUuid(sid) && !isCSCADisciplineComponentSubjectId(sid),
    );
    const missingMetaIds = annualOrderedSubjectIds.filter((sid) => !subjectById.has(sid));
    if (missingMetaIds.length) {
      const { data: addSubj, error: addSubjErr } = await srv
        .from("subjects")
        .select("id, name, code")
        .in("id", missingMetaIds);

      if (!addSubjErr && addSubj?.length) {
        for (const s of addSubj as any[]) {
          subjectById.set(String(s.id), { id: String(s.id), name: s.name ?? null, code: s.code ?? null } as any);
        }
      }
    }

    // 3) Liste matières pour le calcul annuel (coeff bulletin + include)
    const annualSubjectsForReport = annualOrderedSubjectIds
      .map((sid) => {
        const s = subjectById.get(sid);
        const name = (s as any)?.name || (s as any)?.code || "Matière";
        const info = coeffBySubject.get(sid);
        const coeffBulletin = info ? info.coeff : 1;
        const includeInAverage = isCSCA && isCSCALatinOrReligionSubjectMeta(s as any)
          ? false
          : shouldIncludeSubjectInGeneralAverage(
              sid,
              info ? info.include : true
            );

        return {
          subject_id: sid,
          subject_name: name,
          coeff_bulletin: coeffBulletin,
          include_in_average: includeInAverage,
        };
      })
      // tri alpha pour stabilité (nom puis id)
      .sort((a, b) => {
        const an = String(a.subject_name || "");
        const bn = String(b.subject_name || "");
        const c = an.localeCompare(bn, "fr", { sensitivity: "base" });
        if (c !== 0) return c;
        return String(a.subject_id).localeCompare(String(b.subject_id));
      });

    // ✅ Forcer Conduite incluse dans le calcul annuel.
    // CSCA : « Discipline » reste une composante interne de la conduite,
    // pas une matière annuelle affichée/recalculée à part.
    for (const s of annualSubjectsForReport as any[]) {
      const meta = subjectById.get(String(s.subject_id));
      const key = normalizeAsciiToken(`${(meta as any)?.code ?? ""} ${(meta as any)?.name ?? ""}`);
      if (key.includes("conduite") || key.includes("conduct")) {
        s.include_in_average = true;
        const c = Number(s.coeff_bulletin ?? 0);
        if (!c || c <= 0) s.coeff_bulletin = 1;
      }
    }

    // 4) Étendre la liste des sous-matières pour le calcul annuel (si certaines matières n'apparaissent pas au dernier trimestre)
    const annualSubjectComponentById = new Map<string, BulletinSubjectComponent>(subjectComponentById);
    const annualCompsBySubject = new Map<string, BulletinSubjectComponent[]>();
    // seed existing compsBySubject
    compsBySubject.forEach((v, k) => annualCompsBySubject.set(k, v.slice()));

    if (allowSubjectComponents && annualOrderedSubjectIds.length) {
      const { data: addCompData, error: addCompErr } = await srv
        .from("grade_subject_components")
        .select("id, subject_id, label, short_label, coeff_in_subject, order_index, is_active, level")
        .eq("institution_id", institutionId)
        .in("subject_id", annualOrderedSubjectIds);

      if (!addCompErr && addCompData?.length) {
        const rawBySubject = new Map<string, any[]>();

        for (const r of addCompData as any[]) {
          if (r.is_active === false) continue;

          const sid = String(r.subject_id || "");
          if (!sid) continue;

          const arr = rawBySubject.get(sid) || [];
          arr.push(r);
          rawBySubject.set(sid, arr);
        }

        for (const sid of annualOrderedSubjectIds) {
          const chosen = pickBestComponentRows(rawBySubject.get(sid) || [], coeffLevelCandidates);

          for (const r of chosen) {
            const obj: BulletinSubjectComponent = {
              id: String(r.id),
              subject_id: String(r.subject_id),
              label: (r.label ?? r.short_label ?? "Sous-matière") as any,
              short_label: (r.short_label ?? null) as any,
              coeff_in_subject:
                r.coeff_in_subject !== null && r.coeff_in_subject !== undefined
                  ? Number(r.coeff_in_subject)
                  : 1,
              order_index:
                r.order_index !== null && r.order_index !== undefined
                  ? Number(r.order_index)
                  : 1,
            } as any;

            annualSubjectComponentById.set(obj.id, obj);

            const arr = annualCompsBySubject.get(obj.subject_id) || [];
            if (!arr.find((x) => x.id === obj.id)) arr.push(obj);
            annualCompsBySubject.set(obj.subject_id, arr);
          }
        }

        annualCompsBySubject.forEach((arr) => {
          arr.sort((a, b) => (a.order_index ?? 1) - (b.order_index ?? 1));
        });
      }
    }

    // calc moyenne générale d'un élève sur une période
    const computeGeneralAvgMapForRange = async (
      from: string,
      to: string,
      subjectsList: { subject_id: string; coeff_bulletin: number | null; include_in_average: boolean }[],
      compsMap: Map<string, BulletinSubjectComponent[]>,
      compByIdMap: Map<string, BulletinSubjectComponent>,
      conductMap?: Map<string, number | null> | null,
      periodId?: string | null
    ): Promise<Map<string, number | null>> => {
      const out = new Map<string, number | null>();
      studentIds.forEach((sid) => out.set(sid, null));

      const conductSubjectIds = new Set<string>();
      for (const s of subjectsList) {
        if (isConductSubjectId(String(s.subject_id))) conductSubjectIds.add(String(s.subject_id));
      }

      const rangeBonusMaps = await loadAdjustmentBonusMaps({
        academicYear: academicYearForPeriods ?? classRow.academic_year ?? periodMeta.academic_year ?? null,
        periodId: periodId ?? null,
      });

      // evals publiées sur la période
      const { data: eData, error: eErr } = await supabase
        .from("grade_evaluations")
        .select("id, class_id, subject_id, teacher_id, eval_date, scale, coeff, is_published, subject_component_id")
        .eq("class_id", classId)
        .eq("is_published", true)
        .gte("eval_date", from)
        .lte("eval_date", to);

      if (eErr || !eData?.length) return out;

      const pevals = (eData as any[]) as EvalRow[];
      const evalMap = new Map<string, EvalRow>();
      pevals.forEach((ev) => evalMap.set(ev.id, ev));

      const evalIds = pevals.map((ev) => ev.id);

      let pscores: ScoreRow[] = [];
      try {
        pscores = await loadOfficialScoreRowsForEvalIds(evalIds);
      } catch (error) {
        console.warn("[bulletin] scores officiels annuels indisponibles", error);
        return out;
      }

      if (!pscores.length) return out;

      const perStuSub = new Map<string, Map<string, { sumWeighted: number; sumCoeff: number }>>();
      const perStuComp = new Map<
        string,
        Map<string, { subject_id: string; sumWeighted: number; sumCoeff: number }>
      >();

      for (const sc of pscores) {
        const ev = evalMap.get(sc.evaluation_id);
        if (!ev) continue;
        if (!ev.subject_id) continue;
        if (!ev.scale || ev.scale <= 0) continue;
        if (sc.score === null || sc.score === undefined) continue;

        const score = Number(sc.score);
        if (!Number.isFinite(score)) continue;

        const norm20 = (score / ev.scale) * 20;
        const weight = ev.coeff ?? 1;

        let sm = perStuSub.get(sc.student_id);
        if (!sm) {
          sm = new Map();
          perStuSub.set(sc.student_id, sm);
        }
        const cell = sm.get(ev.subject_id) || { sumWeighted: 0, sumCoeff: 0 };
        cell.sumWeighted += norm20 * weight;
        cell.sumCoeff += weight;
        sm.set(ev.subject_id, cell);

        if (ev.subject_component_id) {
          const comp = subjectComponentById.get(ev.subject_component_id);
          if (comp) {
            let cm = perStuComp.get(sc.student_id);
            if (!cm) {
              cm = new Map();
              perStuComp.set(sc.student_id, cm);
            }
            const ccell =
              cm.get(comp.id) || { subject_id: comp.subject_id, sumWeighted: 0, sumCoeff: 0 };
            ccell.sumWeighted += norm20 * weight;
            ccell.sumCoeff += weight;
            cm.set(comp.id, ccell);
          }
        }
      }

      // calc general avg pour chaque élève
      for (const sid of studentIds) {
        const sm = perStuSub.get(sid) || new Map();
        const cm = perStuComp.get(sid) || new Map();

        let academicSumGen = 0;
        let academicSumCoeffGen = 0;
        let conductSumGen = 0;
        let conductSumCoeffGen = 0;
        let conductAlreadyCounted = false;
        let hasAcademicContribution = false;

        for (const s of subjectsList) {
          if (s.include_in_average === false) continue;
          const coeffSub = Number(s.coeff_bulletin ?? 0);
          if (!coeffSub || coeffSub <= 0) continue;

          const comps = compsMap.get(s.subject_id) || [];

          let subAvg: number | null = null;

          // priorité sous-matières si existantes et notées
          if (comps.length) {
            let sum = 0;
            let sumW = 0;

            for (const comp of comps) {
              const ccell = cm.get(comp.id);
              if (!ccell || ccell.sumCoeff <= 0) continue;

              const raw = ccell.sumWeighted / ccell.sumCoeff;
              if (!Number.isFinite(raw)) continue;

              const w = comp.coeff_in_subject ?? 1;
              if (!w || w <= 0) continue;

              sum += raw * w;
              sumW += w;
            }

            if (sumW > 0) subAvg = sum / sumW;
          }

          // fallback eval direct matière
          if (subAvg === null) {
            const cell = sm.get(s.subject_id);
            if (cell && cell.sumCoeff > 0) {
              subAvg = cell.sumWeighted / cell.sumCoeff;
            }
          }

          if (subAvg === null || subAvg === undefined) continue;
          if (!Number.isFinite(subAvg)) continue;

          const subjectBonus =
            rangeBonusMaps.subjectBonusByStudent.get(sid)?.get(String(s.subject_id)) ?? 0;
          const adjustedSubjectAvg = clampAverage20(Number(subAvg) + subjectBonus);
          if (adjustedSubjectAvg === null) continue;
          subAvg = adjustedSubjectAvg;

          const isConduct = conductSubjectIds.has(String(s.subject_id));
          if (isConduct) {
            conductAlreadyCounted = true;
            conductSumGen += Number(subAvg) * coeffSub;
            conductSumCoeffGen += coeffSub;
            continue;
          }

          hasAcademicContribution = true;
          academicSumGen += Number(subAvg) * coeffSub;
          academicSumCoeffGen += coeffSub;
        }

        // ✅ La conduite ne complète que les périodes déjà valides académiquement
        if (hasAcademicContribution) {
          if (!conductAlreadyCounted && conductMap) {
            const c = conductMap.get(sid);
            if (c !== null && c !== undefined && Number.isFinite(Number(c))) {
              conductSumGen += Number(c) * 1;
              conductSumCoeffGen += 1;
            }
          }

          const sumGen = academicSumGen + conductSumGen;
          const sumCoeffGen = academicSumCoeffGen + conductSumCoeffGen;
          let g = sumCoeffGen > 0 ? cleanNumber(sumGen / sumCoeffGen, 4) : null;

          const generalBonus = rangeBonusMaps.generalBonusByStudent.get(sid) ?? 0;
          if (g !== null && g !== undefined && Number.isFinite(Number(g))) {
            const adjustedGeneral = clampAverage20(Number(g) + generalBonus);
            g = adjustedGeneral === null ? null : cleanNumber(adjustedGeneral, 4);
          }

          out.set(sid, g);
        } else {
          out.set(sid, null);
        }
      }

      const rangeOverrideMap = await loadBulletinNcOverrideMap(srvClient, {
        institutionId,
        classId: classRow.id,
        academicYear: academicYearForPeriods ?? classRow.academic_year ?? periodMeta.academic_year ?? null,
        from,
        to,
        scope: "period",
      });

      if (rangeOverrideMap.size) {
        for (const sid of rangeOverrideMap.keys()) {
          out.set(sid, null);
        }
      }

      return out;
    };

    const annualAvgByStudent = new Map<string, number | null>();
    const annualCoverageByStudent = new Map<
      string,
      { expected_periods: number; covered_periods: number; missing_periods: any[]; is_complete: boolean; status: string }
    >();
    studentIds.forEach((sid) => annualAvgByStudent.set(sid, null));

    // ✅ calcule UNE fois par période (évite N_students × N_periods requêtes)
    const periodMaps: { w: number; period: GradePeriodRow; map: Map<string, number | null> }[] = [];

    for (const p of periodsForYear) {
      const from = String(p.start_date);
      const to = String(p.end_date);
      const w =
        p.coeff === null || p.coeff === undefined ? 1 : Math.max(0, Number(p.coeff) || 0) || 1;

      const conductMapForPeriod = await fetchConductAverageMap(from, to);

      const map = await computeGeneralAvgMapForRange(
        from,
        to,
        annualSubjectsForReport,
        annualCompsBySubject,
        annualSubjectComponentById,
        conductMapForPeriod,
        p.id ?? null
      );
      periodMaps.push({ w, period: p, map });
    }

    for (const sid of studentIds) {
      let sum = 0;
      let sumW = 0;
      let covered = 0;
      const missingPeriods: any[] = [];

      for (const pm of periodMaps) {
        const avg = pm.map.get(sid) ?? null;
        if (typeof avg === "number" && Number.isFinite(avg)) {
          sum += avg * pm.w;
          sumW += pm.w;
          covered += 1;
        } else {
          missingPeriods.push({
            from: pm.period.start_date,
            to: pm.period.end_date,
            code: pm.period.code ?? null,
            label: pm.period.label ?? null,
            short_label: pm.period.short_label ?? null,
          });
        }
      }

      const a = sumW > 0 ? cleanNumber(sum / sumW, 4) : null;
      annualAvgByStudent.set(sid, a);
      annualCoverageByStudent.set(sid, {
        expected_periods: periodMaps.length,
        covered_periods: covered,
        missing_periods: missingPeriods,
        is_complete: periodMaps.length > 0 && covered === periodMaps.length,
        status:
          periodMaps.length === 0
            ? "empty"
            : covered === periodMaps.length
              ? "complete"
              : covered > 0
                ? "partial"
                : "empty",
      });
    }

    const annualNcOverrideMap =
      dateFrom && dateTo
        ? await loadBulletinNcOverrideMap(srvClient, {
            institutionId,
            classId: classRow.id,
            academicYear: academicYearForPeriods ?? classRow.academic_year ?? periodMeta.academic_year ?? null,
            from: dateFrom,
            to: dateTo,
            scope: "annual",
          })
        : new Map<string, BulletinNcOverrideRow>();

    if (annualNcOverrideMap.size) {
      for (const sid of annualNcOverrideMap.keys()) {
        annualAvgByStudent.set(sid, null);
        const cov = annualCoverageByStudent.get(sid);
        if (cov) {
          cov.status = "admin_nc";
          cov.is_complete = false;
        }
      }
    }

    const annualRankByStudent = buildRankMapFromAverageMap(annualAvgByStudent);

    for (const it of items) {
      const a = annualAvgByStudent.get(it.student_id) ?? null;
      const r = annualRankByStudent.get(it.student_id) ?? null;
      const annualCoverage =
        annualCoverageByStudent.get(it.student_id) ?? {
          expected_periods: periodMaps.length,
          covered_periods: 0,
          missing_periods: [],
          is_complete: false,
          status: "empty",
        };

      const annualOverride = annualNcOverrideMap.get(String(it.student_id));
      const annualBeforeAdminNc = a;

      (it as any).annual_avg = a;
      (it as any).annual_rank = a !== null ? r : null;
      (it as any).annual_coverage = annualCoverage;
      (it as any).annual_coverage_is_complete = annualCoverage.is_complete;
      (it as any).annual_coverage_status = annualCoverage.status;
      // ✅ Nouvelle règle : une moyenne annuelle calculable reste classable,
      // même si toutes les périodes ne sont pas encore couvertes.
      (it as any).annual_avg_is_complete = a !== null;
      (it as any).annual_avg_status = a !== null ? "complete" : "empty";

      if (annualOverride) {
        (it as any).admin_annual_forced_nc = true;
        (it as any).admin_annual_nc_override = {
          id: annualOverride.id,
          scope: "annual",
          reason: annualOverride.reason,
          missing_subjects_snapshot: annualOverride.missing_subjects_snapshot ?? [],
        };
        (it as any).annual_avg_before_admin_nc = annualBeforeAdminNc;
        (it as any).annual_avg = null;
        (it as any).annual_rank = null;
        (it as any).annual_avg_is_complete = false;
        (it as any).annual_avg_status = "admin_nc";
        (it as any).annual_coverage_status = "admin_nc";
      }
    }
  } else {
    // cohérence: si pas dernier trimestre -> valeurs null
    for (const it of items) {
      (it as any).annual_avg = null;
      (it as any).annual_rank = null;
      (it as any).annual_coverage = null;
      (it as any).annual_coverage_is_complete = false;
      (it as any).annual_coverage_status = "not_last_period";
      (it as any).annual_avg_is_complete = false;
      (it as any).annual_avg_status = "not_last_period";
    }
  }

  // ✅ QR : URL courte /v/[code] (fallback token si besoin)
  const itemsWithQr = await addQrToItems(srvClient, items, {
    origin,
    institutionId,
    classId: classRow.id,
    classAcademicYear: classRow.academic_year ?? null,
    periodMeta: {
      from: periodMeta.from ?? null,
      to: periodMeta.to ?? null,
      code: periodMeta.code ?? null,
      label: periodMeta.label ?? null,
      short_label: periodMeta.short_label ?? null,
      academic_year: periodMeta.academic_year ?? null,
    },
  });

  // ✅ QR PNG server-side
  const itemsWithQrPng = await attachQrPng(itemsWithQr);

  return NextResponse.json({
    ok: true,
    qr: {
      enabled: qrEnabled,
      mode: qrMode,
      verify_path: BULLETIN_VERIFY_SHORT_PREFIX,
      legacy_verify_path: BULLETIN_VERIFY_LEGACY_PATH,
    },
    signatures: { enabled: bulletinSignaturesEnabled },
    class: {
      id: classRow.id,
      label: classRow.label || classRow.code || "Classe",
      code: classRow.code || null,
      academic_year: classRow.academic_year || null,
      level: classRow.level || null,
      official_track_code: classRow.official_track_code || null,
      coefficient_level: coeffLevelCandidates[0] || bulletinLevel || null,
      bulletin_level: bulletinLevel,
      head_teacher: headTeacher
        ? {
            id: headTeacher.id,
            display_name: headTeacher.display_name || null,
            phone: headTeacher.phone || null,
            email: headTeacher.email || null,
          }
        : null,
    },
    period: periodResponse,
    subjects: subjectsForReport,
    subject_groups: subjectGroups,
    subject_components: subjectComponentsForReport,
    items: itemsWithQrPng,
  });
}
